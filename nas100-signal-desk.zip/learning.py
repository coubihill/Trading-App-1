"""Outcome-driven research. Frozen models stay in shadow; never execute orders."""
import hashlib,json,math,time

VERSION='shadow-logistic-1'
MIN_LABELS=120

def features(c):
    f=c['features'];a=f['atr'];s=c['side']
    return [s*f['body_15m']/a,f['range_15m']/a,
            s*(f['ema9']-f['ema20'])/a,s*(f['ema20']-f['ema20_lag3'])/a,
            c['risk_points']/a,2.5/c['risk_points'],
            float(c['rule'].startswith('11:30')),float(c['rule'].startswith('14:00'))]

def probability(model,x):
    z=model['weights'][0]+sum(w*max(-8,min(8,(v-m)/s)) for w,v,m,s in zip(model['weights'][1:],x,model['mean'],model['scale']))
    return 1/(1+math.exp(-max(-35,min(35,z))))

def fit(rows):
    xs=[json.loads(r['features']) for r in rows];n=len(xs);d=len(xs[0])
    mean=[sum(x[j] for x in xs)/n for j in range(d)]
    scale=[max(.01,(sum((x[j]-mean[j])**2 for x in xs)/n)**.5) for j in range(d)]
    xx=[[1]+[max(-8,min(8,(v-m)/s)) for v,m,s in zip(x,mean,scale)] for x in xs]
    yy=[float(r['net_r']>0) for r in rows];w=[0.]*(d+1)
    for _ in range(400):
        grad=[0.]*(d+1)
        for x,y in zip(xx,yy):
            z=sum(a*b for a,b in zip(w,x));p=1/(1+math.exp(-max(-35,min(35,z))))
            for j in range(d+1):grad[j]+=(p-y)*x[j]/n
        w=[v-.08*(g+(.05*v if j else 0)) for j,(v,g) in enumerate(zip(w,grad))]
    return {'weights':w,'mean':mean,'scale':scale,'threshold':.5,'version':VERSION}

def init(store):
    with store.db() as db:
        db.executescript('''CREATE TABLE IF NOT EXISTS learning_samples(
        id TEXT PRIMARY KEY,ticker TEXT NOT NULL,cohort TEXT NOT NULL,signal_time REAL NOT NULL,
        features TEXT NOT NULL,outcome TEXT NOT NULL,state TEXT NOT NULL,closed_at REAL,net_r REAL,
        model_id TEXT,prediction REAL);
        CREATE TABLE IF NOT EXISTS learning_models(
        id TEXT PRIMARY KEY,cohort TEXT NOT NULL,created REAL NOT NULL,cutoff REAL NOT NULL,
        model TEXT NOT NULL,train_count INTEGER NOT NULL,validation_count INTEGER NOT NULL,
        validation TEXT NOT NULL,data_hash TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS learning_pending ON learning_samples(ticker,state);''')

def cohort(c):return c['ticker']+'|'+c['rule_version']+'|'+VERSION

def observe(store,key,c):
    x=features(c);group=cohort(c)
    outcome={'id':key,'ticker':c['ticker'],'root':c['root'],'side':c['side'],
             'signal_time':c['signal_time'],'expires':c['expires'],'risk':c['risk_points'],
             'state':'pending','last_bar':None,'entry':None,'stop':None,'target':None,
             'exit':None,'result':None,'reason':None,'demo':0}
    with store.db() as db:
        model=db.execute('SELECT id,model FROM learning_models WHERE cohort=? AND cutoff<=? ORDER BY created DESC LIMIT 1',(group,c['signal_time'])).fetchone()
        pred=probability(json.loads(model['model']),x) if model else None
        db.execute('INSERT OR IGNORE INTO learning_samples VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                   (key,c['ticker'],group,c['signal_time'],json.dumps(x),json.dumps(outcome),'pending',None,None,model['id'] if model else None,pred))

def advance(store,p,advance_position,point_values):
    with store.db() as db:
        for row in db.execute("SELECT * FROM learning_samples WHERE ticker=? AND state IN ('pending','open')",(p['ticker'],)).fetchall():
            before=json.loads(row['outcome']);after=advance_position(before,p)
            if after==before:continue
            closed=after['last_bar']+300 if after['state']=='closed' else None
            net=after['result']/(after['risk']*point_values[after['root']]) if closed else None
            db.execute('UPDATE learning_samples SET outcome=?,state=?,closed_at=?,net_r=? WHERE id=?',
                       (json.dumps(after),after['state'],closed,net,row['id']))

def stats(rows):
    values=[r['net_r'] for r in rows];gain=sum(max(0,x) for x in values);loss=-sum(min(0,x) for x in values)
    return {'count':len(values),'net_r':sum(values),'profit_factor':gain/loss if loss else None}

def train_if_ready(store):
    """Retrain after 60 fresh labels. Train labels end before validation starts."""
    with store.db() as db:
        groups=[r[0] for r in db.execute("SELECT DISTINCT cohort FROM learning_samples WHERE state='closed'")]
        for group in groups:
            latest=db.execute('SELECT id FROM learning_models WHERE cohort=? ORDER BY created DESC LIMIT 1',(group,)).fetchone()
            if latest and db.execute("SELECT COUNT(*) FROM learning_samples WHERE model_id=? AND state='closed'",(latest['id'],)).fetchone()[0]<60:continue
            rows=[dict(r) for r in db.execute("SELECT * FROM learning_samples WHERE cohort=? AND state='closed' ORDER BY signal_time,id",(group,))]
            if len(rows)<MIN_LABELS:continue
            split=int(len(rows)*.75);cutoff=rows[split]['signal_time']
            train=[r for r in rows[:split] if r['closed_at']<=cutoff];valid=rows[split:]
            if len(train)<80 or len(valid)<30 or len({r['net_r']>0 for r in train})<2:continue
            model=fit(train);accepted=[r for r in valid if probability(model,json.loads(r['features']))>=model['threshold']]
            digest=hashlib.sha256(json.dumps([(r['id'],r['features'],r['net_r'],r['closed_at']) for r in rows],sort_keys=True).encode()).hexdigest()
            ident=hashlib.sha256((group+digest).encode()).hexdigest()[:16]
            validation={'all':stats(valid),'accepted':stats(accepted),'purged':split-len(train)}
            db.execute('INSERT INTO learning_models VALUES(?,?,?,?,?,?,?,?,?)',
                       (ident,group,time.time(),max(r['closed_at'] for r in rows),json.dumps(model),len(train),len(valid),json.dumps(validation),digest))

def status(store):
    with store.db() as db:
        counts={r['state']:r['n'] for r in db.execute('SELECT state,COUNT(*) n FROM learning_samples GROUP BY state')}
        groups=[dict(r) for r in db.execute("SELECT cohort,COUNT(*) n FROM learning_samples WHERE state='closed' GROUP BY cohort")]
        models=[]
        for r in db.execute('SELECT * FROM learning_models ORDER BY created DESC'):
            rows=[dict(x) for x in db.execute("SELECT net_r,prediction FROM learning_samples WHERE model_id=? AND state='closed'",(r['id'],))]
            models.append({'id':r['id'],'train':r['train_count'],'validation':json.loads(r['validation']),
                           'forward':stats(rows),'forward_accepted':stats([x for x in rows if x['prediction']>=.5])})
    return {'mode':'SHADOW ONLY','minimum_closed_per_cohort':MIN_LABELS,'closed':counts.get('closed',0),
            'pending':counts.get('pending',0)+counts.get('open',0),'unresolved':counts.get('unresolved',0),
            'largest_cohort_closed':max([g['n'] for g in groups],default=0),'models':models,
            'detail':'Collecting completed setups. Automatic training starts at 120 closed setups per matching market and rule version. Frozen filters are tested on new setups and cannot change BUY/SELL signals.'}
