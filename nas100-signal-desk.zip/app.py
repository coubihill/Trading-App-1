from __future__ import annotations
import base64,csv,hashlib,hmac,io,json,os,secrets,signal,threading,time,urllib.parse
import learning
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from core import Store,DEFAULTS,candidate,validate_snapshot,process,notify_telegram,event_key,SYDNEY,ENGINE_VERSION,remaining_daily_budget
from datetime import datetime,timedelta

HERE=Path(__file__).resolve().parent

def snapshot_rejection(error):
    """Only fixed diagnostics can be persisted; never echo untrusted payload text."""
    messages={
        'Unexpected or missing snapshot fields':'Bridge fields do not match snapshot version 1',
        'Use bridge version1 on five-minute candles':'Bridge version or timeframe does not match',
        'Use an NQ or MNQ futures chart':'Snapshot root must be NQ or MNQ futures',
        'Unsupported futures symbol':'Unsupported snapshot symbol format',
        'Instrument and symbol disagree':'Snapshot root and symbol disagree',
        'Snapshot must end on a five-minute boundary':'Snapshot end is not a five-minute boundary',
        'Market data is stale; newest completed candle is over90seconds old':'Delayed market data rejected',
        'Market data is future dated':'Future-dated market data rejected',
        'Exactly64 completed candles are required':'Bridge must send exactly 64 completed candles',
        'Invalid candle fields':'Bridge candle field names do not match',
        'Candle timestamps must precede snapshot end':'Invalid snapshot candle timestamps',
        'Candles must be strictly chronological':'Snapshot candles are out of order',
        'Invalid OHLC prices':'Invalid snapshot candle prices',
        'Missing newest completed candle':'Newest completed candle is missing',
        'Invalid indicator value':'Invalid snapshot indicator value',
        'ATR is inconsistent with market price':'Snapshot ATR is inconsistent with price',
        'Expected a finite number':'Snapshot has a missing or non-finite numeric value',
    }
    return messages.get(str(error),'Invalid or incomplete market snapshot rejected')

class App:
    def __init__(self,data_dir=None,preview=False,password=None,webhook_token=None):
        self.data=Path(data_dir or os.environ.get('DATA_DIR',HERE/'runtime'));self.data.mkdir(parents=True,exist_ok=True)
        self.preview=preview;secretfile=self.data/'secrets.json'
        if secretfile.exists():saved=json.loads(secretfile.read_text())
        else:
            saved={'password':secrets.token_urlsafe(32),'webhook':secrets.token_urlsafe(32)}
            secretfile.write_text(json.dumps(saved));secretfile.chmod(0o600)
        self.password=password or os.environ.get('ADMIN_PASSWORD') or saved['password']
        self.webhook=webhook_token or os.environ.get('WEBHOOK_TOKEN') or saved['webhook']
        if len(self.password)<24 or len(self.webhook)<24:raise ValueError('Admin password and webhook token must have at least24characters')
        self.csrf=secrets.token_urlsafe(32);self.store=Store(self.data/'signals.sqlite3');self.stop=threading.Event();self.worker_alive=False
        # No credentials are printed or included in health/status responses.
    def status(self):
        cfg=self.store.config()
        with self.store.db() as c:
            events=[dict(r) for r in c.execute('SELECT id,received,bar_end,ticker,status,decision,demo FROM events ORDER BY received DESC LIMIT 100')]
            positions=[dict(r) for r in c.execute('SELECT * FROM positions ORDER BY signal_time DESC LIMIT 100')]
            active=c.execute("SELECT * FROM positions WHERE demo=0 AND state IN ('pending','open','unresolved') LIMIT 1").fetchone()
            last=c.execute('SELECT MAX(bar_end) FROM events WHERE demo=0').fetchone()[0]
            queue=c.execute("SELECT COUNT(*) FROM events WHERE status IN ('queued','processing')").fetchone()[0]
            reviews=c.execute('SELECT COUNT(*) FROM reviews WHERE day=?',(datetime.now(SYDNEY).strftime('%Y-%m-%d'),)).fetchone()[0]
            notifications=[dict(r) for r in c.execute('SELECT * FROM notifications ORDER BY updated DESC LIMIT 20')]
        for r in events:r['decision']=json.loads(r['decision']) if r['decision'] else None
        if active and not any(r['id']==active['id'] for r in positions):positions.insert(0,dict(active))
        _,daily_pnl=self.store.daily(datetime.now(SYDNEY).strftime('%Y-%m-%d'))
        safe={k:v for k,v in cfg.items() if k not in ['api_key','telegram_token']}
        safe['api_key_configured']=bool(cfg['api_key']);safe['telegram_token_configured']=bool(cfg['telegram_token'])
        safe['ai_budget']=self.store.ai_budget_status()
        safe['feed_delivery']=self.store.feed_delivery_status()
        return {'preview':self.preview,'worker_alive':self.worker_alive,'csrf':self.csrf,'config':safe,'events':events,'positions':positions,'last_snapshot':last,'queue':queue,'reviews_today':reviews,'notifications':notifications,'summary':self.store.statistics(),'evaluations':self.store.evaluation_statistics(),'learning':learning.status(self.store),'daily_remaining_usd':round(remaining_daily_budget(daily_pnl,cfg['max_daily_loss_usd']),2),'version':ENGINE_VERSION}
    def worker(self):
        self.worker_alive=True
        try:
            while not self.stop.is_set():
                row=self.store.claim()
                if row is None:self.stop.wait(.25);continue
                try:decision=process(self.store,row)
                except Exception:decision={'action':'NO TRADE','reason':'Internal processing error; inspect service logs before resuming','mode':'PRACTICE','time':time.time()}
                self.store.finish(row['id'],decision)
                notify_telegram(self.store,row['id'],decision,self.store.config())
        finally:self.worker_alive=False
    def demo(self):
        from datetime import timezone
        dt=datetime.now(SYDNEY).replace(hour=14,minute=0,second=0,microsecond=0)
        while dt.weekday()>=5:dt-=timedelta(days=1)
        end=dt.timestamp();cases=[]
        for direction in [1,-1]:
            candles=[]
            for i in range(64):
                op=20000+direction*i;cl=op+direction*.75
                candles.append({'t':int((end-(64-i)*300)*1000),'o':op,'h':max(op,cl)+1,'l':min(op,cl)-1,'c':cl})
            p={'version':1,'ticker':'CME_MINI:MNQ1!','root':'MNQ','timeframe':'5','bar_end':int(end*1000),'atr':20,'ema9':20000+direction*60,'ema20':20000+direction*55,'ema20_lag3':20000+direction*50,'candles':candles}
            validate_snapshot(p,end);c,_=candidate(p);assert c is not None
            cases.append(dict(action=c['action'],mode='DEMO',reason='Synthetic example. No AI call, market feed or executed trade.',reference_entry=c['reference_entry'],stop=c['stop'],target=c['target'],estimated_risk_usd=c['estimated_risk_usd'],rule=c['rule'],time=time.time()))
        cases.append({'action':'NO TRADE','mode':'DEMO','reason':'Example: stale data or insufficient evidence. No live decision.','time':time.time()})
        with self.store.db() as db:
            for i,c in enumerate(cases):
                db.execute("INSERT INTO events(id,received,bar_end,ticker,payload,status,decision,demo) VALUES(?,?,?,?,?,'done',?,1)",(secrets.token_hex(16),time.time()-i,end,'DEMO MNQ','{}',json.dumps(c)))
        return {'ok':True,'examples':3}

def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        server_version='SignalDesk/1'
        def log_message(self,*args):pass # Never log webhook URL tokens or credentials.
        def send(self,status,value,kind='application/json'):
            data=json.dumps(value,allow_nan=False).encode() if kind=='application/json' else value.encode() if isinstance(value,str) else value
            self.send_response(status);self.send_header('Content-Type',kind+'; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-src https://www.tradingview-widget.com; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");self.end_headers();self.wfile.write(data)
        def authed(self):
            host=self.headers.get('Host','').split(':')[0]
            if app.preview and self.client_address[0] in ['127.0.0.1','::1'] and host in ['127.0.0.1','localhost']:return True
            value=self.headers.get('Authorization','')
            try:
                raw=base64.b64decode(value.removeprefix('Basic '),validate=True).decode();user,password=raw.split(':',1)
                if value.startswith('Basic ') and hmac.compare_digest(user,'owner') and hmac.compare_digest(password,app.password):return True
            except Exception:pass
            self.send_response(401);self.send_header('WWW-Authenticate','Basic realm="NAS100 Signal Desk", charset="UTF-8"');self.send_header('Content-Length','0');self.end_headers();return False
        def read_body(self):
            if self.headers.get('Transfer-Encoding'):raise ValueError('Chunked requests are unsupported')
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=40000:raise ValueError('Request body must be between1and40000bytes')
            self.connection.settimeout(3)
            return json.loads(self.rfile.read(length))
        def do_GET(self):
            route=urllib.parse.urlsplit(self.path).path
            if route=='/health':return self.send(200 if app.worker_alive else 503,{'ok':app.worker_alive,'service':'practice-signal-desk'})
            if not self.authed():return
            if route=='/':return self.send(200,(HERE/'web/index.html').read_text(encoding='utf-8'),'text/html')
            if route in ['/app.js','/style.css']:
                return self.send(200,(HERE/'web'/route[1:]).read_text(encoding='utf-8'),'application/javascript' if route.endswith('.js') else 'text/css')
            if route=='/api/status':return self.send(200,app.status())
            if route=='/api/export':
                output=io.StringIO();writer=csv.writer(output);writer.writerow(['received_utc','mode','ticker','action','reason','entry_reference','stop','target','estimated_risk_usd'])
                with app.store.db() as c:
                    for row in c.execute("SELECT * FROM events WHERE status='done' ORDER BY received"):
                        from datetime import timezone
                        d=json.loads(row['decision'] or '{}');vals=[datetime.fromtimestamp(row['received'],timezone.utc).isoformat(),d.get('mode','PRACTICE'),row['ticker'],d.get('action'),d.get('reason'),d.get('reference_entry'),d.get('stop'),d.get('target'),d.get('estimated_risk_usd')]
                        writer.writerow(["'"+str(v) if isinstance(v,str) and v.startswith(('=','+','-','@')) else v for v in vals])
                return self.send(200,output.getvalue(),'text/csv')
            return self.send(404,{'error':'Not found'})
        def do_POST(self):
            route=urllib.parse.urlsplit(self.path).path
            if route.startswith('/webhook/'):
                token=route[len('/webhook/'):]
                if not hmac.compare_digest(token,app.webhook):return self.send(404,{'error':'Not found'})
                try:
                    body=self.read_body();p=validate_snapshot(body);key,new=app.store.enqueue(p)
                    app.store.record_delivery(True,'Fresh market snapshot accepted')
                    return self.send(202,{'accepted':True,'duplicate':not new,'event':key})
                except (ValueError,TypeError,KeyError,json.JSONDecodeError) as e:
                    app.store.record_delivery(False,snapshot_rejection(e))
                    return self.send(400,{'error':'Invalid, stale or incomplete market snapshot'})
                except Exception:return self.send(503,{'error':'Snapshot could not be persisted; no signal produced'})
            if not self.authed():return
            origin=self.headers.get('Origin','');host=self.headers.get('Host','')
            if origin and urllib.parse.urlsplit(origin).netloc!=host:return self.send(403,{'error':'Cross-origin request denied'})
            if not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),app.csrf):return self.send(403,{'error':'Refresh the dashboard before changing settings'})
            try:
                body=self.read_body()
                if route=='/api/settings':app.store.update_config(body);return self.send(200,{'ok':True})
                if route=='/api/demo':return self.send(200,app.demo())
                if route=='/api/connection':return self.send(200,{'webhook_path':'/webhook/'+app.webhook,'bridge':'TradingView_Bridge.pine'})
                if route=='/api/reconcile':app.store.close_unresolved(str(body['id']),body['result']);return self.send(200,{'ok':True})
                return self.send(404,{'error':'Not found'})
            except (ValueError,TypeError,KeyError) as e:return self.send(400,{'error':str(e)[:250]})
            except Exception:return self.send(500,{'error':'Request failed; no action assumed'})
    return Handler

def main():
    os.umask(0o077)
    preview=os.environ.get('LOCAL_PREVIEW')=='1'
    bind='127.0.0.1' if preview else '0.0.0.0'
    port=int(os.environ.get('PORT','8765'))
    if not preview and not os.environ.get('ADMIN_PASSWORD'):raise SystemExit('Set ADMIN_PASSWORD to a random password of at least24characters before starting hosted mode.')
    app=App(preview=preview)
    worker=threading.Thread(target=app.worker,daemon=True);worker.start()
    server=ThreadingHTTPServer((bind,port),make_handler(app));server.daemon_threads=True
    print(f'Signal Desk ready on port{port}; '+('LOCAL DEMO, not hosted online.' if preview else 'Hosted practice mode; configure from the password-protected dashboard.'),flush=True)
    try:server.serve_forever(poll_interval=.3)
    except KeyboardInterrupt:pass
    finally:app.stop.set();server.server_close();worker.join(timeout=2)

if __name__=='__main__':main()
