## Reliability release 1.4.7 — 24 October 2026

Current release notes supersede older deployment-status paragraphs below. Existing hosted app and live CME bridge are connected; no completed prospective AI outcome is established as of the pre-release audit. Learning remains shadow only.

External JSON now rejects duplicate field names and non-standard non-finite constants. AI explanations must be nonblank, bounded, and free of control characters; the same contract applies to all paper-review paths. Ambiguous replies remain failures, never approvals. Responses above the existing 200 KB limit are explicitly rejected.

Locked/busy database claims and final decision saves retry without rerunning AI. During a lock, health returns unavailable and the dashboard suppresses signals. Other storage failures still stop the worker visibly. Duplicate webhook deliveries remain idempotent even with a full queue. Concurrent identical budget reservations return unavailable rather than charging twice; the shared $5 cap remains unchanged.

The dashboard ignores superseded status responses and clears actionable levels when consent, key configuration, or model is missing. Research manifests include the review validator and strict decoder source so this change creates separately identifiable cohorts; all previous rows remain intact. Trading rules, costs, risk limits, learning threshold and prompts are unchanged. No automatic promotion or broker orders.

## Snapshot validation diagnostics — version 1.3.2

The connection status now identifies fixed validation failures such as a bridge schema mismatch, wrong root, wrong candle count or malformed timestamps. No untrusted payload or exception text is echoed into the diagnostic. Validation and trade rules are unchanged. A dedicated privacy/schema regression check is included.

## Connection diagnostics update — version 1.3.1

Authenticated webhook attempts now update one durable connection diagnostic record without storing secrets, URLs or invalid payloads. Delayed candles are rejected and shown clearly in the dashboard; they never enter the signal queue or learning samples. Wrong-token requests cannot change the diagnostic. 48 Python tests and dashboard state checks passed locally. This does not confirm a live feed; actual real-time CME snapshots still must be verified.

## Current hosted release — October 22, 2026, version 1.3.0

The paid persistent Render service is live at https://nas100-signal-desk.onrender.com/. AI review is configured under explicit user approval; monitoring remains paused pending real TradingView snapshots and real-time data verification. No real trade orders are supported.

The app reserves US$0.10 before every attempted AI review, stops at US$5 per UTC month, and never refunds failed calls. This is a conservative app allowance, not an OpenAI account billing limit or a report of actual charges. It does not cover other uses of the same API key. Production calls are restricted to gpt-5.6-terra, 12,000 request bytes and 1,200 output tokens with reasoning effort none; re-check pricing before changing this profile. One synthetic API smoke test passed locally with a US$0.10 reservation, without recording a market signal.

New learning samples include all fixed-rule candidates from fresh, non-demo snapshots for the selected instrument, even while monitoring is paused. Immutable entry-time features and same-cost shadow outcomes are stored separately from the practice journal. Data gaps remain unresolved and cannot become training labels. Cohorts are separated by symbol, rule version and learning version.

After 120 completed matching samples, a regularized logistic filter trains on the first chronological 75%, with labels overlapping validation purged. Validation uses the final 25% (minimum 30). Scaling is fitted only on training data. The model, data hash and cutoff are frozen. Only subsequent setups receive frozen predictions before their outcome is known. After 60 fresh completed predictions, a new frozen challenger can train. All learned filters remain SHADOW ONLY and cannot change live directions, levels, position size or risk limits. No profitability or calibrated win probability has been established; automatic promotion is deliberately not implemented.

Verification: 46 Python tests and offline dashboard state checks passed. The hosted worker and authenticated status report version 1.3.0. The paid key smoke test used synthetic candles only. Zero real TradingView snapshots have been received. TradingView displayed a ten-minute NQ delay and blocked webhook setup until the user enables two-factor authentication. Earlier dated notes below describe prior stages, not current deployment status.

---

# NAS100 Signal Desk

A hosted, practice-only signal review service. It receives completed TradingView futures candles, applies fixed experimental rules, asks an optional AI reviewer to approve or veto a candidate, and records every assessment. It has no broker credentials, account connection or order endpoints.

## What is built

- Password-protected dashboard with BUY, SELL or NO TRADE, reference entry, SL, TP, estimated dollar risk and signal journal.
- TradingView market bridge for standard five-minute MNQ/NQ futures candles.
- Durable SQLite webhook inbox with duplicate suppression and asynchronous reviews. The webhook persists a snapshot and replies before any AI call.
- Sydney local-clock/DST handling. Monitoring receives snapshots while the market is open; candidate entries are restricted to the research schedule below.
- AI review via OpenAI Responses API with a strict approve/veto JSON schema. The reviewer cannot change direction, prices, size or risk limits. Missing/invalid/late reviews produce NO TRADE.
- One modeled position at a time, daily signal and AI-call limits, risk limits, stale-data rejection, and a paper journal that does not count demo examples.
- Optional approved-signal phone notifications through your Telegram bot. No actual notification was sent during development.
- Docker image definition and current Render deployment blueprint with a persistent disk. This is prepared for deployment, not an already hosted service.

## Current status

Built and tested locally. Hosted deployment, a real OpenAI request, real Telegram delivery and TradingView-to-host end-to-end delivery still require setup and verification. No secrets are included in this package. A local preview does not run while your PC is off.

## To put it online

1. Create a Render account at https://dashboard.render.com/register. You also need a Git repository that Render can access. A private GitHub repository is suitable; upload the files in this folder, excluding everything covered by `.gitignore`. Do not upload `runtime/`, API keys, webhook links or passwords.
2. In Render, create a Blueprint from the repository containing `render.yaml`. If this folder is nested, set the blueprint path and service root directory to this folder. The included service uses one paid `0.5c-512mb` instance and a 1GB persistent disk in Singapore. Review and approve the current charges before creating it. Free services that sleep are unsuitable for a webhook requiring a prompt response, and they do not retain local SQLite state.
3. After deployment, open its HTTPS address. Log in with username **owner**. Retrieve the generated **ADMIN_PASSWORD** privately from the service's Render environment settings. Never paste it into chat. The health check must be healthy. Do not enable `LOCAL_PREVIEW` on the hosted instance. Use only one instance: SQLite and paper-position state assume a single service process.
4. Open **Setup** in the app. Select your practice instrument and limits. Enter your own OpenAI API key and use the approved cost-profile model gpt-5.6-terra. Check the market-data sharing consent and enable AI. API billing is separate from hosting; confirm pricing in your API account. A synthetic paid API connectivity test passed on October 22; this is not strategy validation.
5. Optionally create a Telegram bot with BotFather, start a conversation with it, and enter its bot token and your numeric chat ID in Setup. Enable notification consent and the switch. These tokens authorize that bot; keep them private. Notifications are at-most-once attempted. Failures appear in status and are not automatically replayed, to avoid stale or duplicate trade suggestions.
6. Add `TradingView_Bridge.pine` in TradingView, save/compile it, and apply it to standard five-minute MNQ or NQ futures candles with real-time data. Choose the same instrument in the dashboard. The bridge was compiled, privately saved and applied on the five-minute NQ1! chart on October20,2026. The chart currently reports delayed CME data; real-time entitlement is not confirmed. Select NQ in the app for this chart, or switch the chart to MNQ to match the default app instrument. It sends 64 completed candles plus ATR14/EMA9/EMA20 computed on chart history; it does not use screenshots or account information.
7. Create a TradingView alert with condition **Any alert() function call**. In the dashboard, choose **Show my private webhook URL** and paste that HTTPS URL into the alert's webhook field. Do not add the key to Pine code. TradingView requires two-factor authentication for webhooks and accepts public webhook ports80/443; the hosted HTTPS address uses443. The app's internal port10000 is not your public webhook URL.
8. Confirm the first fresh snapshot appears, then activate practice monitoring. Keep the alert active and check its expiration. Recreate the alert after changing the Pine source, because TradingView runs its saved snapshot. Verify a controlled practice review and Telegram notification before relying on notifications. No missed or delayed notification should be treated as an instruction to enter late.

The generated WEBHOOK_TOKEN is a shared secret embedded in the webhook URL. It authenticates knowledge of that secret, not a cryptographic proof that a request originated at TradingView. Keep access private; rotate the environment value and recreate the alert if exposed. Neither this token nor the OpenAI key grants access to your Combine.

## Research rules

All prices and levels are deterministic, and all candidates remain experimental. The broad research did not establish a robust profitable strategy. AI review has not been shown to improve these setups.

| Sydney entry | Candidate | Target | Maximum hold |
|---|---|---:|---:|
| 11:30AM | Compression breakout | 3R | 5hours |
| 2:00PM | EMA-aligned15min trend; stop distance at least10points | 3R | 5hours |
| 3:00PM | Strong15min momentum | 3R | 5hours |

No candidates are created at other five-minute closes. NO TRADE is expected frequently. The schedule is not a promise of a daily signal. Entry times are within11AM–5PM Sydney; holds can extend to8PM. Stop distance is max(ATR14, distance to preceding15min extreme+0.25), rounded upward to0.25. Levels round to futures tick0.25. Default configuration is one MNQ contract, $200 estimated planned risk per signal, $200 modeled daily loss limit, one practice signal per Sydney day and at most12 AI reviews/day. These are software defaults, not a suitability recommendation or Topstep account protection.

## Paper results and reference prices

An alert's reference entry is the just-completed candle close plus0.5point adverse slippage. The service does not know the next fill price or your actual entry. A paper position remains pending until the next candle arrives, then models entry at its open plus0.5point adverse slippage and recalculates its SL/TP. This live-alert workflow differs from the backtests that entered at a known next candle open. No historical PF should be assigned to the AI service.

Paper exits use five-minute candles, stopfirst if both levels are touched, 0.25point target penetration, worse opening fills on gaps through stops, and0.5point stop/time-exit slippage. Modeled round-trip cost is2points. Planned dollar risk includes2points modeled cost plus0.5point exit slippage. Gaps and actual execution can exceed it. Dollar point values are2forMNQ and20forNQ. These are estimates; commissions, spreads and actual fills may differ.

Missing position candles leave the position **unresolved** and block new signals until its journal result is reconciled. Do not enter invented outcomes. Limits and position state refer only to the app's paper journal; the app cannot see manual positions, fills, drawdown, payouts or account rule breaches in Topstep. It never enforces real stops or exits.

AI receives only the candidate and16recent completed candles. It has no news feed, order book, calibrated win probability or privileged market knowledge. It can approve or veto the supplied direction, not invent another trade. Model choice is recorded in settings; paid AI calls occur only after explicit enabling and data consent. Pause monitoring before changing models if you want separately comparable evaluation periods.

## Local preview and tests

On this PC, `Start-Preview.ps1` starts a hidden local preview using the bundled Python runtime when available. It binds only127.0.0.1:8765 and marks itself LOCAL DEMO. It is intentionally not reachable by TradingView. Hosted mode always requires a long admin password.

For another computer, use Python3.12+, install `requirements.txt`, then run `python -m unittest -v test_signal_desk` for the tests. Start with `LOCAL_PREVIEW=1 python app.py` for a local-only preview, or configure ADMIN_PASSWORD, WEBHOOK_TOKEN, DATA_DIR and PORT in your host's secret manager for hosted mode. Use HTTPS in front of the hosted service; HTTP Basic authentication must never be exposed over plain HTTP.

SQLite, settings and API secrets live under DATA_DIR, backed by the attached disk. Disk access is sensitive: protect the hosting account, restrict repository access, and back up the journal. No filesystem storage is included in the release ZIP. Deleting the disk loses state. Do not run multiple copies against the same journal.

## References checked October20,2026

- OpenAI structured output: https://developers.openai.com/api/docs/guides/structured-outputs
- TradingView webhooks/time limits: https://www.tradingview.com/support/solutions/43000529348-how-to-configure-webhook-alerts/
- TradingView saved alert snapshots: https://www.tradingview.com/pine-script-docs/concepts/alerts/
- Render blueprint schema: https://render.com/docs/blueprint-spec
- Render free-tier limits: https://render.com/docs/free
- Telegram Bot API: https://core.telegram.org/bots/api#sendmessage

The service is informational and practice-only. It does not connect to Topstep order flow; rules about broker API execution and trading from a personal device are not bypassed by this hosted alert service.


## October20 TradingView setup update

The market bridge is installed in TradingView as NAS100 Signal Desk - Market Bridge, version1. The current NQ1! chart is five-minute, extended hours, and CME_MINI_DL delayed data. No webhook alert has been activated because the public HTTPS receiver and real-time data are not ready. The dashboard now excludes demo examples from its main assessment and hides stale reference levels. Demo examples remain labeled in the journal. A matching TradingView chart link follows the app instrument.


## October21 improvement session — version1.1.0

- Performance totals now cover every closed non-demo paper trade, including profit factor, expectancy and closed-trade drawdown. They no longer silently truncate to the latest100 positions. An active position remains visible even beyond the recent-history display.
- Each new candidate must fit both its per-trade limit and the remaining modeled daily loss budget, before and after remote AI review. Profits cannot increase the original daily allowance. Actual gaps can still exceed planned risk; this does not enforce real account limits.
- AI model/key changes during an in-flight review cancel that signal. The journal records model ID, engine/rule version and review duration; it never returns the API key.
- Every candidate actually submitted for AI review gets a separate counterfactual paper outcome, including vetoes and unavailable reviews. Approved and vetoed outcomes use the exact same execution function as approved paper trades. Missing paths remain unresolved. These hypothetical positions do not occupy the real paper-position slot or count as signals.
- The comparison groups are separated by model and rule version. Only valid APPROVE/VETO responses enter the comparative statistics. Unavailable reviews are counted separately. Late/cancelled approvals remain candidate counterfactuals, not executed paper trades. The candidates are selected by existing feed/risk/daily/active-position gates; this is not a test of all possible chart setups. Overlapping candidate outcomes are not a tradable baseline portfolio. There is no AI performance conclusion yet.
- Status freshness now uses the newest market candle time, rather than its delivery time.
-39 unit and real HTTP checks pass. A separate short sustained HTTP/SQLite test exercises duplicate alerts, synthetic AI failures and restarts; see the companion soak report for its actual duration. No paid AI calls or real notifications were used.

Additional research on the already-selected2PM trend setup used10,000 circular five-trade block resamples per year, seed20261021.2025:88trades, PF1.473, higher-costPF1.146, drop-two-bestPF1.266; descriptive95%PF interval0.872–2.256.2026:100trades, PF1.418, higher-costPF1.159, drop-two-bestPF1.236; interval1.014–1.934. These intervals do not adjust for the thousands of strategies previously searched and are not a future-profit probability. This does not establish a PF2 strategy. No reserved2020–22 data was inspected. Raw output: NAS100_Signal_Desk_Research_Update.json.

The local OpenAI key is saved privately but remains untested against OpenAI. AI and monitoring remain disabled. Hosted deployment still requires Render login/setup, repository access and approval of actual hosting charges. The Pine bridge is unchanged; its earlier compile verification remains applicable.


## October22 chart and connection update — version1.2.0

The dashboard now embeds TradingView's Advanced Chart in a cross-origin iframe, with a five-minute NQ/MNQ symbol matching the configured practice instrument and Sydney time. Instrument changes reload the frame; normal five-second status refreshes do not. Chart controls cannot silently switch it to a different instrument. The TradingView attribution remains visible. Widget configuration contains no API key, admin password, webhook token or CSRF value. Parent scripts remain restricted to this app; the frame policy allows only the TradingView widget host. No external script runs in the dashboard's parent document.

An explicit SIGNALS NOT LIVE banner and Setup checklist distinguish chart display from the signal receiver. The app requires its separate real-time TradingView webhook feed. TradingView widgets do not run our Pine script, and paid TradingView data subscriptions do not transfer to widgets. The widget can be delayed or unavailable for a symbol; the matching full-chart link remains available. The app never substitutes another market.

BUY/SELL and entry/SL/TP display only for fresh approved assessments while monitoring, AI, feed confirmation and the worker are enabled. Pausing or losing the connection clears actionable levels and shows NO TRADE. These changes do not fabricate approvals or activate monitoring.

Verification:40 Python service/HTTP tests; offline JavaScript state tests cover BUY, SELL, pause, expiry, offline handling and instrument matching. Both dashboard and worker health return HTTP200. TradingView widget endpoint returns HTTP200. Browser visual verification was blocked by the browser security gate; iframe rendering, symbol entitlement and current price are not independently verified. No new preview screenshot is claimed.

Actual live setup remains incomplete: zero real snapshots; the private API key is saved but model, data consent and AI switch are not configured. The local receiver cannot receive cloud webhooks at127.0.0.1. Render login, repository deployment and approval of actual hosting charges remain necessary, followed by a real-time futures alert and end-to-end review verification.

Official widget references:
- https://www.tradingview.com/widget-docs/widgets/charts/advanced-chart/
- https://www.tradingview.com/widget-docs/faq/data/
- https://www.tradingview.com/widget-docs/faq/general/


## Hosted deployment — October22,2026

The actual service is https://nas100-signal-desk.onrender.com, Render service srv-dbcq76avcj2c73fgjo90, source commit59efa2fe5b684b21f1af52ee62b1c513b21382cd on nas100-signal-desk. Always-on compute isUS$7/month and the1GB disk isUS$0.25/month, approved by the user. The database and private configuration live on /var/data from the first successful launch. The earlier failed service remains Free.

Public /health returns200; the dashboard/assets return200 with authentication; unauthenticated /api/status returns401. Saved NQ configuration and API key persisted after a Render-confirmed service restart. OpenAI accepted the saved key on a metadata request; no paid inference was made. Login details are stored only in the excluded local runtime folder. The browser client blocked opening the public site, so chart rendering remains unverified.

Hosting is live, but live signals are not: zero real snapshots, monitoring/AI disabled, no real-time TradingView webhook configured. These remaining steps are necessary before BUY/SELL alerts can be reviewed live.


### Prospective comparison

Version 1.4.1 adds separate NQ/MNQ baseline and AI paper accounts. Each has one contract, its own position and daily limits, timestamped immutable predictions, actual-market feeds and frozen cost/model/rule cohorts. Published TopstepX round-turn costs are NQ $3.78 and MNQ $1.22 (checked 23 October 2026). Fills start at a future complete bar; additional slippage is stressed. These are modeled results, not broker execution. The main signal journal uses its older conservative two-point cost assumption and must not be pooled with this comparison. No profitable result is established. Failed, skipped and unresolved outcomes remain visible. Comparison AI reviews share the existing $5 monthly app reservation allowance.
