// Offline DOM doubles test state transitions; this is not a browser render test.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/web/index.html','utf8');
const ids=[...html.matchAll(/id="([^"]+)"/g)].map(x=>x[1]);
const element=()=>({classList:{toggle(){}},replaceChildren(){},append(){},showModal(){},close(){},textContent:'',value:'',checked:false,hidden:false});
const nodes=Object.fromEntries(ids.map(id=>[id,element()]));
const context=vm.createContext({document:{getElementById(id){assert(nodes[id],'Missing element '+id);return nodes[id]},createElement:element},setInterval(){},setTimeout(){},Intl,Date,encodeURIComponent,Error,fetch:async()=>{throw Error('Offline test')}});
vm.runInContext(fs.readFileSync(__dirname+'/web/app.js','utf8'),context);
const state={preview:true,worker_alive:true,csrf:'unit-test',config:{instrument:'NQ',max_risk_usd:200,max_daily_loss_usd:200,max_signals_per_day:1,model:'',enabled:false,ai_enabled:false,feed_confirmed:false,data_consent:false,api_key_configured:true},last_snapshot:null,summary:{closed:0,net_usd:0,win_rate:null,profit_factor:null,expectancy_usd:null,closed_drawdown_usd:0},reviews_today:0,evaluations:[],events:[],positions:[],daily_remaining_usd:200};
async function main(){
 await vm.runInContext('refresh()',context);
 assert.equal(nodes.action.textContent,'NO TRADE');assert.equal(nodes['signal-mode'].textContent,'DISCONNECTED');
 context.sample=state;vm.runInContext('render(sample)',context);
 assert.equal(nodes['live-title'].textContent,'SIGNALS NOT LIVE');assert.equal(nodes.action.textContent,'NO TRADE');
 let cfg=JSON.parse(decodeURIComponent(nodes['market-chart'].src.split('#')[1]));
 assert.equal(cfg.symbol,'CME_MINI:NQ1!');assert.equal(cfg.interval,'5');assert.equal(cfg.allow_symbol_change,false);
 state.preview=false;Object.assign(state.config,{enabled:true,ai_enabled:true,feed_confirmed:true,data_consent:true,model:'test'});state.last_snapshot=Date.now()/1000;
 state.events=[{received:Date.now()/1000,demo:0,ticker:'CME_MINI:NQ1!',decision:{action:'BUY',time:Date.now()/1000,expires:Date.now()/1000+300,reference_entry:25000,stop:24980,target:25060,reason:'Synthetic test'}}];
 vm.runInContext('render(sample)',context);assert.equal(nodes.action.textContent,'BUY');assert.equal(nodes.entry.textContent,'25000.00');assert.equal(nodes['live-title'].textContent,'SIGNAL SERVICE CONNECTED · PRACTICE');
 state.events[0].decision.action='SELL';vm.runInContext('render(sample)',context);assert.equal(nodes.action.textContent,'SELL');
 state.config.enabled=false;vm.runInContext('render(sample)',context);assert.equal(nodes.action.textContent,'NO TRADE');assert.equal(nodes.entry.textContent,'—');
 state.config.enabled=true;state.events[0].decision.time-=100;vm.runInContext('render(sample)',context);assert.equal(nodes.action.textContent,'NO TRADE');assert.equal(nodes.entry.textContent,'—');
 state.config.instrument='MNQ';vm.runInContext('render(sample)',context);cfg=JSON.parse(decodeURIComponent(nodes['market-chart'].src.split('#')[1]));assert.equal(cfg.symbol,'CME_MINI:MNQ1!');
 assert(!nodes['market-chart'].src.includes('api_key'));assert(!nodes['market-chart'].src.includes('csrf'));
 console.log('Dashboard state checks passed: offline, unconfigured, BUY, SELL, pause, expiry, instrument matching, and credential-free chart configuration.');
}
main().catch(e=>{console.error(e);process.exitCode=1});
