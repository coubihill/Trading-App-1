"""Prospective independent paper accounts. Never submit broker orders."""
import hashlib, inspect, json, math, time

VERSION='paired-forward-3'
# Published TopstepX round-turn fees, checked 23 October 2026. Fixed per cohort.
ROUND_TURN_USD={'NQ':3.78,'MNQ':1.22}

def audit_export(store,limit=2000):
    """Consistent bounded read of research records only, never configuration secrets."""
    if not isinstance(limit,int) or not 1<=limit<=2000:raise ValueError('Invalid audit export limit')
    records={};totals={}
    # Whitelist exact research tables. Never serialize settings, credentials or webhook data.
    tables={'cohorts':('comparison_cohorts','created,id'),
            'checks':('comparison_checks','bar_end,event_id'),
            'decisions':('comparison_decisions','created,id'),
            'positions':('comparison_positions','id'),
            'errors':('comparison_errors','created,event_id'),
            'breakout_cohorts':('breakout_cohorts','created,id'),'breakout_checks':('breakout_checks','bar_end,event_id'),
            'breakout_decisions':('breakout_decisions','created,id'),'breakout_positions':('breakout_positions','id'),
            'breakout_errors':('breakout_errors','created,event_id')}
    with store.db() as db:
        db.execute('BEGIN')
        for label,(table,ordering) in tables.items():
            totals[label]=db.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]
            records[label]=[dict(r) for r in db.execute('SELECT * FROM '+table+' ORDER BY '+ordering+' LIMIT ?',(limit,))]
    digest=hashlib.sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return {'format':'signal-desk-research-audit-1','exported_at':time.time(),
            'records':records,'total_rows':totals,'limit_per_table':limit,
            'truncated':any(totals[k]>len(records[k]) for k in totals),
            'records_sha256':digest,
            'note':'Research-only consistent database read. Hash checks file integrity, not independent timestamp attestation. If truncated, this is not the complete journal. No broker orders or executed-account results.'}

def init(store):
    with store.db() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS comparison_errors(event_id TEXT PRIMARY KEY,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS comparison_checks(event_id TEXT PRIMARY KEY,received REAL NOT NULL,bar_end REAL NOT NULL,ticker TEXT NOT NULL,scheduled INTEGER NOT NULL,setup_found INTEGER NOT NULL,reason TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS comparison_cohorts(id TEXT PRIMARY KEY,created REAL NOT NULL,manifest TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS comparison_decisions(id TEXT PRIMARY KEY,cohort TEXT NOT NULL,event_id TEXT NOT NULL,arm TEXT NOT NULL,created REAL NOT NULL,ticker TEXT NOT NULL,verdict TEXT NOT NULL,reason TEXT NOT NULL,candidate TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS comparison_positions(id TEXT PRIMARY KEY,cohort TEXT NOT NULL,arm TEXT NOT NULL,ticker TEXT NOT NULL,state TEXT NOT NULL,outcome TEXT NOT NULL);
        ''')

def record_check(store,event,core,clock=time.time):
    """Separate observational diagnostics; cannot approve or change a trade."""
    if event.get('demo',0):return
    p=json.loads(event['payload']);now=clock()
    try:core.validate_snapshot(p,now)
    except (ValueError,TypeError,KeyError):return
    c,reason=core.candidate(p)
    dt=core.datetime.fromtimestamp(p['bar_end']/1000,core.SYDNEY)
    scheduled=dt.weekday()<5 and dt.hour*60+dt.minute in [690,840,900]
    with store.db() as db:db.execute('INSERT OR IGNORE INTO comparison_checks VALUES(?,?,?,?,?,?,?)',
        (event['id'],now,p['bar_end']/1000,p['ticker'],int(scheduled),int(c is not None),reason))

def manifest_for(cfg,core):
    source=''.join(inspect.getsource(f) for f in [core.candidate,core.advance_position,core.review_ai,core.validate_review,core.strict_json_loads,process])
    return {'version':VERSION,'rule':core.RULE_VERSION,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
            'universe':['NQ','MNQ'],'model':cfg['model'],'risk_usd':cfg['max_risk_usd'],
            'daily_loss_usd':cfg['max_daily_loss_usd'],'daily_entries':cfg['max_signals_per_day'],
            'contracts':1,'entry_slippage_points':.5,'stop_slippage_points':.5,'round_turn_usd':ROUND_TURN_USD,
            'fees_source':'https://help.topstep.com/en/articles/8284213-topstepx-commissions-and-fees',
            'entry':'First complete bar opening after prediction; at least one full bar after setup',
            'stress':'Subtract 3 extra index points per closed trade; diagnostic, not a new strategy',
            'note':'Independent baseline and AI accounts. Published platform fees; spread/slippage are fixed assumptions, not broker fills.'}

def process(store,event,main_decision,core,reviewer=None,clock=time.time):
    if event.get('demo',0):return
    p=json.loads(event['payload']);now=clock()
    try:core.validate_snapshot(p,now)
    except (ValueError,TypeError,KeyError):return
    cfg=store.config()
    # Advance old cohorts too: changing a configuration never erases losses.
    with store.db() as db:
        for r in db.execute("SELECT * FROM comparison_positions WHERE ticker=? AND state IN ('pending','open')",(p['ticker'],)).fetchall():
            out=core.advance_position(json.loads(r['outcome']),p)
            if out['state']=='closed':
                out['result']=round(out['result']+2*core.POINT_VALUE[out['root']]-out.get('commission_usd',2*core.POINT_VALUE[out['root']]),2)
            db.execute('UPDATE comparison_positions SET state=?,outcome=? WHERE id=?',(out['state'],json.dumps(out),r['id']))
    if not cfg['enabled'] or not cfg['feed_confirmed']:return
    c,_=core.candidate(p)
    if not c:return
    c=dict(c,estimated_risk_usd=round((c['risk_points']+.5)*core.POINT_VALUE[p['root']]+ROUND_TURN_USD[p['root']],2))
    m=manifest_for(cfg,core);cid=hashlib.sha256(json.dumps(m,sort_keys=True).encode()).hexdigest()[:24]
    with store.db() as db:db.execute('INSERT OR IGNORE INTO comparison_cohorts VALUES(?,?,?)',(cid,now,json.dumps(m,sort_keys=True)))
    for arm in ['baseline','ai']:
        did=cid+'|'+event['id']+'|'+arm
        with store.db() as db:
            if db.execute('SELECT 1 FROM comparison_decisions WHERE id=?',(did,)).fetchone():continue
            rows=[dict(r) for r in db.execute('SELECT state,outcome FROM comparison_positions WHERE cohort=? AND arm=? AND ticker=?',(cid,arm,p['ticker']))]
        rows=[json.loads(r['outcome']) for r in rows]
        pnl=sum(r['result'] or 0 for r in rows if r['state']=='closed' and core.local_date(r['last_bar'])==c['date'])
        entries=sum(core.local_date(r['setup_time'])==c['date'] for r in rows)
        reason=None
        if any(r['state'] in ['pending','open','unresolved'] for r in rows):reason='Account already has a position or unresolved data gap'
        elif entries>=m['daily_entries']:reason='Daily entry limit'
        elif c['estimated_risk_usd']>min(m['risk_usd'],core.remaining_daily_budget(pnl,m['daily_loss_usd'])):reason='Risk limit'
        verdict='SKIP' if reason else 'APPROVE'
        if not reason and arm=='ai':
            if not(cfg['ai_enabled'] and cfg['data_consent'] and cfg['api_key'] and cfg['model']):verdict='UNAVAILABLE';reason='AI not enabled or configured'
            elif main_decision.get('ai') and main_decision.get('candidate',{}).get('estimated_risk_usd')==c['estimated_risk_usd']:
                verdict=main_decision['ai']['verdict'];reason=main_decision['ai']['reason']
            elif main_decision.get('model') and 'AI review unavailable' in main_decision.get('reason',''):
                verdict='UNAVAILABLE';reason='Main review failed; not retried'
            elif not store.reserve_review('comparison|'+event['id'],c['date'],cfg['max_ai_calls_per_day']):
                verdict='UNAVAILABLE';reason='Shared AI budget or daily review limit'
            else:
                try:
                    review=(reviewer or core.review_ai)(c,p,cfg)
                    core.validate_review(review)
                    verdict=review['verdict'];reason=review['reason'][:400]
                except Exception:verdict='UNAVAILABLE';reason='Review failed; not retried'
        finished=clock()
        latest=store.config()
        if verdict=='APPROVE' and (finished-p['bar_end']/1000>90 or not latest['enabled'] or not latest['feed_confirmed']):
            verdict='SKIP';reason='Review expired or monitoring paused'
        if verdict=='APPROVE' and arm=='ai' and (
                not latest['ai_enabled'] or not latest['data_consent'] or
                latest['model']!=cfg['model'] or latest['api_key']!=cfg['api_key'] or
                any(latest[k]!=cfg[k] for k in ['max_risk_usd','max_daily_loss_usd','max_signals_per_day'])):
            verdict='SKIP';reason='AI permissions, model or risk settings changed during review'
        # Prediction is committed before a future entry bar. Never fill at an already elapsed bar open.
        entry_at=max(c['signal_time']+300,math.ceil(finished/300)*300)
        outcome={'id':did,'ticker':p['ticker'],'root':p['root'],'side':c['side'],'setup_time':c['signal_time'],
                 'commission_usd':ROUND_TURN_USD[p['root']],
                 'signal_time':entry_at,'expires':c['expires'],'risk':c['risk_points'],'state':'pending',
                 'last_bar':None,'entry':None,'stop':None,'target':None,'exit':None,'result':None,'reason':None,'demo':0}
        with store.db() as db:
            cur=db.execute('INSERT OR IGNORE INTO comparison_decisions VALUES(?,?,?,?,?,?,?,?,?)',
                (did,cid,event['id'],arm,finished,p['ticker'],verdict,reason or 'Fixed rules; no AI filter',json.dumps(c,sort_keys=True)))
            if cur.rowcount and verdict=='APPROVE':db.execute('INSERT INTO comparison_positions VALUES(?,?,?,?,?,?)',(did,cid,arm,p['ticker'],'pending',json.dumps(outcome)))

def status(store,core):
    result=[]
    with store.db() as db:
        cohorts=db.execute('SELECT * FROM comparison_cohorts ORDER BY created').fetchall()
        for cohort in cohorts:
            for ticker in [r[0] for r in db.execute('SELECT DISTINCT ticker FROM comparison_decisions WHERE cohort=?',(cohort['id'],))]:
                for arm in ['baseline','ai']:
                    ds=db.execute('SELECT verdict FROM comparison_decisions WHERE cohort=? AND ticker=? AND arm=?',(cohort['id'],ticker,arm)).fetchall()
                    rows=[json.loads(r[0]) for r in db.execute('SELECT outcome FROM comparison_positions WHERE cohort=? AND ticker=? AND arm=?',(cohort['id'],ticker,arm))]
                    stressed=[dict(r,result=r['result']-3*core.POINT_VALUE[r['root']]) if r['state']=='closed' and r['result'] is not None else r for r in rows]
                    result.append({'cohort':cohort['id'],'created':cohort['created'],'manifest':json.loads(cohort['manifest']),
                                   'ticker':ticker,'arm':arm,'decisions':len(ds),'unavailable':sum(r[0]=='UNAVAILABLE' for r in ds),
                                   'skipped':sum(r[0]=='SKIP' for r in ds),'vetoed':sum(r[0]=='VETO' for r in ds),
                                   'pending':sum(r['state'] in ['pending','open'] for r in rows),'unresolved':sum(r['state']=='unresolved' for r in rows),
                                   'performance':core.performance(rows),'risk_adjusted':risk_adjusted(rows,core),
                                   'stress':core.performance(stressed),'stress_risk_adjusted':risk_adjusted(stressed,core)})
        errors=db.execute('SELECT COUNT(*) FROM comparison_errors').fetchone()[0]
        checks=[dict(r) for r in db.execute('SELECT * FROM comparison_checks ORDER BY bar_end DESC,ticker LIMIT 20')]
        scheduled_checks=[dict(r) for r in db.execute('SELECT * FROM comparison_checks WHERE scheduled=1 ORDER BY bar_end DESC,ticker LIMIT 20')]
    return {'version':VERSION,'accounts':result,'checks':checks,'scheduled_checks':scheduled_checks,'processing_errors':errors,'detail':'Separate one-contract paper accounts by market and filter. No orders. Insufficient evidence until completed prospective trades; modeled fills and costs only.'}

def risk_adjusted(rows,core):
    """Normalize each net outcome by its original modeled stop risk including fees.

    This is planned-risk R, not account percentage return. Gaps can lose over 1 R.
    Keep unresolved/pending paths outside both numerator and denominator.
    """
    closed=sorted((r for r in rows if r['state']=='closed' and r.get('result') is not None and not r.get('demo',0)),key=lambda r:(r.get('last_bar') or 0,r['id']))
    values=[];risks=[]
    for r in closed:
        original=(r['risk']+.5)*core.POINT_VALUE[r['root']]+r.get('commission_usd',2*core.POINT_VALUE[r['root']])
        if original<=0:raise ValueError('Invalid original risk')
        risks.append(original);values.append(r['result']/original)
    profit=sum(max(x,0) for x in values);loss=-sum(min(x,0) for x in values)
    equity=peak=dd=0.
    for value in values:equity+=value;peak=max(peak,equity);dd=max(dd,peak-equity)
    return {'closed':len(values),'net_r':round(sum(values),6),
            'mean_r':round(sum(values)/len(values),6) if values else None,
            'profit_factor_r':profit/loss if loss else None,'closed_drawdown_r':round(dd,6),
            'mean_initial_risk_usd':sum(risks)/len(risks) if risks else None,
            'detail':'Net modeled outcomes / original planned stop risk including fees. Not a $50K account return; gaps may exceed 1R.'}
