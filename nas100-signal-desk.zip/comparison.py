"""Prospective independent paper accounts. Never submit broker orders."""
import hashlib, inspect, json, math, time

VERSION='paired-forward-2'
# Published TopstepX round-turn fees, checked 23 October 2026. Fixed per cohort.
ROUND_TURN_USD={'NQ':3.78,'MNQ':1.22}

def init(store):
    with store.db() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS comparison_errors(event_id TEXT PRIMARY KEY,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS comparison_cohorts(id TEXT PRIMARY KEY,created REAL NOT NULL,manifest TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS comparison_decisions(id TEXT PRIMARY KEY,cohort TEXT NOT NULL,event_id TEXT NOT NULL,arm TEXT NOT NULL,created REAL NOT NULL,ticker TEXT NOT NULL,verdict TEXT NOT NULL,reason TEXT NOT NULL,candidate TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS comparison_positions(id TEXT PRIMARY KEY,cohort TEXT NOT NULL,arm TEXT NOT NULL,ticker TEXT NOT NULL,state TEXT NOT NULL,outcome TEXT NOT NULL);
        ''')

def manifest_for(cfg,core):
    source=''.join(inspect.getsource(f) for f in [core.candidate,core.advance_position,core.review_ai])
    return {'version':VERSION,'rule':core.RULE_VERSION,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
            'universe':['NQ','MNQ'],'model':cfg['model'],'risk_usd':cfg['max_risk_usd'],
            'daily_loss_usd':cfg['max_daily_loss_usd'],'daily_entries':cfg['max_signals_per_day'],
            'contracts':1,'entry_slippage_points':.5,'stop_slippage_points':.5,'round_turn_usd':ROUND_TURN_USD,
            'fees_source':'https://help.topstep.com/en/articles/8284213-topstepx-commissions-and-fees',
            'entry':'First complete bar opening after prediction; at least one full bar after setup',
            'stress':'Subtract 3 extra index points per closed trade; diagnostic, not a new strategy',
            'note':'Independent baseline and AI accounts. Published platform fees; spread/slippage are fixed assumptions, not broker fills.'}

def process(store,event,main_decision,core,reviewer=None,clock=time.time):
    if event.get('demo',0):return
    p=json.loads(event['payload']);now=clock()
    try:core.validate_snapshot(p,now)
    except (ValueError,TypeError,KeyError):return
    cfg=store.config()
    # Advance old cohorts too: changing a configuration never erases losses.
    with store.db() as db:
        for r in db.execute("SELECT * FROM comparison_positions WHERE ticker=? AND state IN ('pending','open')",(p['ticker'],)).fetchall():
            out=core.advance_position(json.loads(r['outcome']),p)
            if out['state']=='closed':
                out['result']=round(out['result']+2*core.POINT_VALUE[out['root']]-out.get('commission_usd',2*core.POINT_VALUE[out['root']]),2)
            db.execute('UPDATE comparison_positions SET state=?,outcome=? WHERE id=?',(out['state'],json.dumps(out),r['id']))
    if not cfg['enabled'] or not cfg['feed_confirmed']:return
    c,_=core.candidate(p)
    if not c:return
    c=dict(c,estimated_risk_usd=round((c['risk_points']+.5)*core.POINT_VALUE[p['root']]+ROUND_TURN_USD[p['root']],2))
    m=manifest_for(cfg,core);cid=hashlib.sha256(json.dumps(m,sort_keys=True).encode()).hexdigest()[:24]
    with store.db() as db:db.execute('INSERT OR IGNORE INTO comparison_cohorts VALUES(?,?,?)',(cid,now,json.dumps(m,sort_keys=True)))
    for arm in ['baseline','ai']:
        did=cid+'|'+event['id']+'|'+arm
        with store.db() as db:
            if db.execute('SELECT 1 FROM comparison_decisions WHERE id=?',(did,)).fetchone():continue
            rows=[dict(r) for r in db.execute('SELECT state,outcome FROM comparison_positions WHERE cohort=? AND arm=? AND ticker=?',(cid,arm,p['ticker']))]
        rows=[json.loads(r['outcome']) for r in rows]
        pnl=sum(r['result'] or 0 for r in rows if r['state']=='closed' and core.local_date(r['last_bar'])==c['date'])
        entries=sum(core.local_date(r['setup_time'])==c['date'] for r in rows)
        reason=None
        if any(r['state'] in ['pending','open','unresolved'] for r in rows):reason='Account already has a position or unresolved data gap'
        elif entries>=m['daily_entries']:reason='Daily entry limit'
        elif c['estimated_risk_usd']>min(m['risk_usd'],core.remaining_daily_budget(pnl,m['daily_loss_usd'])):reason='Risk limit'
        verdict='SKIP' if reason else 'APPROVE'
        if not reason and arm=='ai':
            if not(cfg['ai_enabled'] and cfg['data_consent'] and cfg['api_key'] and cfg['model']):verdict='UNAVAILABLE';reason='AI not enabled or configured'
            elif main_decision.get('ai') and main_decision.get('candidate',{}).get('estimated_risk_usd')==c['estimated_risk_usd']:
                verdict=main_decision['ai']['verdict'];reason=main_decision['ai']['reason']
            elif main_decision.get('model') and 'AI review unavailable' in main_decision.get('reason',''):
                verdict='UNAVAILABLE';reason='Main review failed; not retried'
            elif not store.reserve_review('comparison|'+event['id'],c['date'],cfg['max_ai_calls_per_day']):
                verdict='UNAVAILABLE';reason='Shared AI budget or daily review limit'
            else:
                try:
                    review=(reviewer or core.review_ai)(c,p,cfg)
                    if review.get('verdict') not in ['APPROVE','VETO'] or not isinstance(review.get('reason'),str):raise ValueError('Review schema')
                    verdict=review['verdict'];reason=review['reason'][:400]
                except Exception:verdict='UNAVAILABLE';reason='Review failed; not retried'
        finished=clock()
        if verdict=='APPROVE' and (finished-p['bar_end']/1000>90 or not store.config()['enabled']):
            verdict='SKIP';reason='Review expired or monitoring paused'
        # Prediction is committed before a future entry bar. Never fill at an already elapsed bar open.
        entry_at=max(c['signal_time']+300,math.ceil(finished/300)*300)
        outcome={'id':did,'ticker':p['ticker'],'root':p['root'],'side':c['side'],'setup_time':c['signal_time'],
                 'commission_usd':ROUND_TURN_USD[p['root']],
                 'signal_time':entry_at,'expires':c['expires'],'risk':c['risk_points'],'state':'pending',
                 'last_bar':None,'entry':None,'stop':None,'target':None,'exit':None,'result':None,'reason':None,'demo':0}
        with store.db() as db:
            cur=db.execute('INSERT OR IGNORE INTO comparison_decisions VALUES(?,?,?,?,?,?,?,?,?)',
                (did,cid,event['id'],arm,finished,p['ticker'],verdict,reason or 'Fixed rules; no AI filter',json.dumps(c,sort_keys=True)))
            if cur.rowcount and verdict=='APPROVE':db.execute('INSERT INTO comparison_positions VALUES(?,?,?,?,?,?)',(did,cid,arm,p['ticker'],'pending',json.dumps(outcome)))

def status(store,core):
    result=[]
    with store.db() as db:
        cohorts=db.execute('SELECT * FROM comparison_cohorts ORDER BY created').fetchall()
        for cohort in cohorts:
            for ticker in [r[0] for r in db.execute('SELECT DISTINCT ticker FROM comparison_decisions WHERE cohort=?',(cohort['id'],))]:
                for arm in ['baseline','ai']:
                    ds=db.execute('SELECT verdict FROM comparison_decisions WHERE cohort=? AND ticker=? AND arm=?',(cohort['id'],ticker,arm)).fetchall()
                    rows=[json.loads(r[0]) for r in db.execute('SELECT outcome FROM comparison_positions WHERE cohort=? AND ticker=? AND arm=?',(cohort['id'],ticker,arm))]
                    stressed=[dict(r,result=r['result']-3*core.POINT_VALUE[r['root']]) if r['state']=='closed' and r['result'] is not None else r for r in rows]
                    result.append({'cohort':cohort['id'],'created':cohort['created'],'manifest':json.loads(cohort['manifest']),
                                   'ticker':ticker,'arm':arm,'decisions':len(ds),'unavailable':sum(r[0]=='UNAVAILABLE' for r in ds),
                                   'skipped':sum(r[0]=='SKIP' for r in ds),'vetoed':sum(r[0]=='VETO' for r in ds),
                                   'pending':sum(r['state'] in ['pending','open'] for r in rows),'unresolved':sum(r['state']=='unresolved' for r in rows),
                                   'performance':core.performance(rows),'stress':core.performance(stressed)})
        errors=db.execute('SELECT COUNT(*) FROM comparison_errors').fetchone()[0]
    return {'version':VERSION,'accounts':result,'processing_errors':errors,'detail':'Separate one-contract paper accounts by market and filter. No orders. Insufficient evidence until completed prospective trades; modeled fills and costs only.'}
