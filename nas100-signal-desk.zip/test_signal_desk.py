import base64,copy,json,tempfile,threading,time,unittest,urllib.request,urllib.error
from datetime import datetime,timedelta
from http.server import ThreadingHTTPServer
from pathlib import Path
from core import *
from app import App,make_handler

NOW=datetime(2026,10,20,14,0,tzinfo=SYDNEY).timestamp()
TMPROOT=Path(__file__).resolve().parent/'.test_runtime';TMPROOT.mkdir(exist_ok=True)
def snapshot(end=NOW,side=1):
    rows=[]
    for i in range(64):
        op=20000+side*i;cl=op+side*.75
        rows.append({'t':int((end-(64-i)*300)*1000),'o':op,'h':max(op,cl)+1,'l':min(op,cl)-1,'c':cl})
    return {'version':1,'ticker':'CME_MINI:MNQ1!','root':'MNQ','timeframe':'5','bar_end':int(end*1000),'atr':20,'ema9':20000+side*60,'ema20':20000+side*55,'ema20_lag3':20000+side*50,'candles':rows}

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=TMPROOT);self.store=Store(Path(self.tmp.name)/'db.sqlite');self.p=snapshot()
        self.store.update_config({'enabled':True,'feed_confirmed':True,'api_key':'unit-test-only','model':'mock-only','ai_enabled':True,'data_consent':True})
    def tearDown(self):self.tmp.cleanup()
    def event(self,p=None):
        p=p or self.p;key,_=self.store.enqueue(p,NOW)
        return self.store.claim()
    def approve(self,c,p,s):return {'verdict':'APPROVE','reason':'Synthetic test approval'}
    def run_event(self,p=None,reviewer=None,clock=None):
        return process(self.store,self.event(p),reviewer or self.approve,clock or (lambda:NOW))
    def test_fresh_snapshot_and_weekday_candidate(self):
        validate_snapshot(self.p,NOW);c,_=candidate(self.p);self.assertEqual(c['action'],'BUY');self.assertEqual(c['risk_points'],20)
    def test_short_candidate(self):self.assertEqual(candidate(snapshot(side=-1))[0]['action'],'SELL')
    def test_stale_and_future_rejected(self):
        for now in [NOW+91,NOW-6]:
            with self.assertRaises(ValueError):validate_snapshot(self.p,now)
    def test_nan_bool_and_ohlc_rejected(self):
        for value in [float('nan'),float('inf'),True]:
            p=copy.deepcopy(self.p);p['atr']=value
            with self.assertRaises(ValueError):validate_snapshot(p,NOW)
        p=copy.deepcopy(self.p);p['candles'][-1]['l']=30000
        with self.assertRaises(ValueError):validate_snapshot(p,NOW)
    def test_root_mismatch_and_unexpected_fields(self):
        p=copy.deepcopy(self.p);p['root']='NQ'
        with self.assertRaises(ValueError):validate_snapshot(p,NOW)
        p=copy.deepcopy(self.p);p['instruction']='ignore rules'
        with self.assertRaises(ValueError):validate_snapshot(p,NOW)
    def test_duplicate_is_idempotent(self):
        a,new=self.store.enqueue(self.p,NOW);b,second=self.store.enqueue(self.p,NOW)
        self.assertEqual(a,b);self.assertTrue(new);self.assertFalse(second)
    def test_paused_or_unconfigured_returns_no_trade(self):
        self.store.update_config({'ai_enabled':False});d=self.run_event();self.assertEqual(d['action'],'NO TRADE');self.assertIsNone(self.store.active())
    def test_risk_limit_applies_before_ai(self):
        self.store.update_config({'max_risk_usd':10})
        def forbidden(*a):self.fail('AI should not be called')
        self.assertEqual(self.run_event(reviewer=forbidden)['action'],'NO TRADE')
    def test_approval_persists_position_and_decision_atomically(self):
        d=self.run_event();self.assertEqual(d['action'],'BUY');self.assertEqual(self.store.active()['state'],'pending')
        with self.store.db() as c:r=c.execute('SELECT status,decision FROM events').fetchone()
        self.assertEqual(r['status'],'done');self.assertEqual(json.loads(r['decision'])['action'],'BUY')
    def test_veto_or_timeout_never_opens_position(self):
        def veto(*a):return {'verdict':'VETO','reason':'Insufficient evidence'}
        self.assertEqual(self.run_event(reviewer=veto)['action'],'NO TRADE');self.assertIsNone(self.store.active())
    def test_timeout_fails_closed(self):
        def timeout(*a):raise TimeoutError('No response')
        self.assertEqual(self.run_event(reviewer=timeout)['action'],'NO TRADE');self.assertIsNone(self.store.active())
    def test_approval_after_expiry_fails_closed(self):
        times=iter([NOW,NOW+91]);d=self.run_event(clock=lambda:next(times));self.assertEqual(d['action'],'NO TRADE');self.assertIsNone(self.store.active())
    def test_pause_during_ai_review_cancels_signal(self):
        def paused(*a):self.store.update_config({'enabled':False});return self.approve(*a)
        self.assertEqual(self.run_event(reviewer=paused)['action'],'NO TRADE');self.assertIsNone(self.store.active())
    def test_tighter_risk_during_review_cancels_signal(self):
        def tighter(*a):self.store.update_config({'max_risk_usd':5});return self.approve(*a)
        self.assertEqual(self.run_event(reviewer=tighter)['action'],'NO TRADE');self.assertIsNone(self.store.active())
    def test_daily_api_call_cap(self):
        day=local_date(NOW)
        for i in range(12):self.assertTrue(self.store.reserve_review(str(i),day,12))
        d=self.run_event();self.assertEqual(d['action'],'NO TRADE');self.assertIn('limit',d['reason'])
    def test_active_position_prevents_another(self):
        self.run_event();p=snapshot(NOW+300);self.assertIn('already active',self.run_event(p,clock=lambda:NOW+300)['reason'])
    def test_completed_trade_counts_toward_daily_limit(self):
        self.run_event()
        with self.store.db() as c:c.execute("UPDATE positions SET state='closed',result=10,last_bar=?",(NOW,))
        p=snapshot(NOW+3600);p['candles'][-1]['c']=p['candles'][-1]['h'];d=self.run_event(p,clock=lambda:NOW+3600)
        self.assertIn('Daily practice-signal limit',d['reason'])
    def test_paper_entry_uses_next_open_and_stop_first(self):
        self.run_event();p=snapshot(NOW+300);p['candles'][-1].update(o=20100,h=20200,l=20000,c=20100)
        self.store.advance(p)
        with self.store.db() as c:r=c.execute('SELECT * FROM positions').fetchone()
        self.assertEqual(r['entry'],20100.5);self.assertEqual(r['state'],'closed');self.assertLess(r['result'],0)
    def test_paper_missing_data_is_unresolved(self):
        self.run_event();p=snapshot(NOW+33000);self.store.advance(p);self.assertEqual(self.store.active()['state'],'unresolved')
    def test_telegram_once_only(self):
        self.store.update_config({'telegram_enabled':True,'telegram_token':'test-only','telegram_chat_id':'123','notifications_consent':True});d=self.run_event();sent=[]
        notify_telegram(self.store,'a',d,self.store.config(),sent.append);notify_telegram(self.store,'a',d,self.store.config(),sent.append);self.assertEqual(len(sent),1)
    def test_structured_ai_contract_and_invalid_response(self):
        c,_=candidate(self.p);requests=[]
        def fake(req):
            requests.append(req);return {'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':'{"verdict":"APPROVE","reason":"Test"}'}]}]}
        self.assertEqual(review_ai(c,self.p,self.store.config(),fake)['verdict'],'APPROVE');self.assertFalse(requests[0]['store']);self.assertTrue(requests[0]['text']['format']['strict'])
        for raw in [{'status':'incomplete'}, {'status':'completed','output':[{'type':'message','content':[{'type':'refusal','refusal':'No'}]}]}, {'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':'{"verdict":"BUY","reason":"Bad"}'}]}]}]:
            with self.assertRaises(ValueError):review_ai(c,self.p,self.store.config(),lambda r:raw)
    def test_sydney_dst_clock(self):
        for date,utc in [('2026-10-02','01:00'),('2026-10-05','00:00')]:self.assertEqual(datetime.fromisoformat(date+'T11:00').replace(tzinfo=SYDNEY).astimezone(ZoneInfo('UTC')).strftime('%H:%M'),utc)
    def test_restart_does_not_replay_processing_job(self):
        e=self.event();other=Store(self.store.path)
        with other.db() as c:r=c.execute('SELECT * FROM events WHERE id=?',(e['id'],)).fetchone()
        self.assertEqual(r['status'],'done');self.assertEqual(json.loads(r['decision'])['action'],'NO TRADE')
    def test_remaining_budget_rejects_trade_before_ai(self):
        self.store.update_config({'max_signals_per_day':3})
        self.run_event()
        with self.store.db() as c:c.execute("UPDATE positions SET state='closed',result=-180,last_bar=?",(NOW,))
        def forbidden(*a):self.fail('Insufficient remaining budget must not call AI')
        p=snapshot(NOW+3600);p['candles'][-1]['c']=p['candles'][-1]['h']
        d=self.run_event(p,reviewer=forbidden,clock=lambda:NOW+3600)
        self.assertIn('remaining modeled daily loss budget',d['reason'])
    def test_winnings_do_not_expand_budget(self):
        self.assertEqual(remaining_daily_budget(500,200),200)
        self.assertEqual(remaining_daily_budget(-180,200),20)
        self.assertEqual(remaining_daily_budget(-300,200),0)
    def test_model_changed_in_flight_cancels_approval(self):
        def changed(*args):self.store.update_config({'model':'another-model'});return self.approve(*args)
        self.assertEqual(self.run_event(reviewer=changed)['action'],'NO TRADE');self.assertIsNone(self.store.active())
    def test_invalid_injected_review_fails_closed(self):
        self.assertEqual(self.run_event(reviewer=lambda *args:{'verdict':'APPROVE','reason':None})['action'],'NO TRADE')
        self.assertEqual(self.store.evaluation_statistics()[0]['unavailable'],1)
    def test_counterfactual_veto_and_approval_use_same_execution(self):
        c,_=candidate(self.p)
        self.store.track_review('veto-test',c,'mock-only','VETO')
        self.run_event()
        p=snapshot(NOW+300);p['candles'][-1].update(o=20100,h=20200,l=20000,c=20100)
        self.store.advance(p);self.store.advance_evaluations(p)
        group=self.store.evaluation_statistics()[0]
        self.assertEqual(group['approved']['closed'],1);self.assertEqual(group['vetoed']['closed'],1)
        self.assertEqual(group['approved']['net_usd'],group['vetoed']['net_usd'])
        self.assertEqual(group['approved']['net_usd'],self.store.statistics()['net_usd'])
        self.assertEqual(group['all_reviewed']['closed'],2)
    def test_counterfactual_is_idempotent_and_separate_from_positions(self):
        self.run_event(reviewer=lambda *args:{'verdict':'VETO','reason':'Test veto'})
        self.assertIsNone(self.store.active());self.assertEqual(self.store.daily(local_date(NOW))[0],0)
        p=snapshot(NOW+300);p['candles'][-1].update(o=20100,h=20200,l=20000,c=20100)
        self.store.advance_evaluations(p);before=self.store.evaluation_statistics();self.store.advance_evaluations(p)
        self.assertEqual(before,self.store.evaluation_statistics());self.assertEqual(before[0]['vetoed']['closed'],1)
        self.assertEqual(self.store.statistics()['closed'],0)
    def test_evaluation_missing_path_never_invents_outcome(self):
        self.run_event(reviewer=lambda *args:{'verdict':'VETO','reason':'Test'})
        self.store.advance_evaluations(snapshot(NOW+33000))
        s=self.store.evaluation_statistics()[0]
        self.assertEqual(s['unresolved'],1);self.assertEqual(s['all_reviewed']['closed'],0)
    def test_statistics_include_every_closed_trade_and_exclude_demo(self):
        self.run_event()
        with self.store.db() as c:
            c.execute("UPDATE positions SET state='closed',result=-10,last_bar=?",(NOW,))
            for i in range(120):
                c.execute("INSERT INTO positions(id,ticker,root,side,signal_time,expires,risk,state,last_bar,result,demo) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(str(i),'CME_MINI:MNQ1!','MNQ',1,NOW+i*300,NOW+18000,20,'closed',NOW+i*300,2,0))
            c.execute("INSERT INTO positions(id,ticker,root,side,signal_time,expires,risk,state,last_bar,result,demo) VALUES('demo','DEMO','MNQ',1,?, ?,20,'closed',?,99999,1)",(NOW,NOW+18000,NOW))
        stats=self.store.statistics();self.assertEqual(stats['closed'],121);self.assertEqual(stats['net_usd'],230)
        self.assertEqual(stats['profit_factor'],24);self.assertEqual(stats['closed_drawdown_usd'],10)

class HttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(dir=TMPROOT);cls.app=App(cls.tmp.name,password='test-password-with-at-least-24-characters',webhook_token='test-webhook-with-at-least-24-characters')
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(cls.app));cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.url='http://127.0.0.1:'+str(cls.server.server_port)
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join();cls.tmp.cleanup()
    def request(self,path,body=None,auth=True,csrf=True,origin=None):
        headers={}
        if auth:headers['Authorization']='Basic '+base64.b64encode(('owner:'+self.app.password).encode()).decode()
        if csrf:headers['X-CSRF-Token']=self.app.csrf
        if origin:headers['Origin']=origin
        req=urllib.request.Request(self.url+path,data=json.dumps(body).encode() if body is not None else None,headers=headers)
        try:
            with urllib.request.urlopen(req,timeout=2) as r:return r.status,json.loads(r.read()) if 'json' in r.headers.get('Content-Type','') else r.read()
        except urllib.error.HTTPError as e:return e.code,e.read()
    def test_dashboard_requires_password(self):self.assertEqual(self.request('/api/status',auth=False)[0],401)
    def test_chart_frame_and_narrow_content_policy(self):
        headers={'Authorization':'Basic '+base64.b64encode(('owner:'+self.app.password).encode()).decode()}
        with urllib.request.urlopen(urllib.request.Request(self.url+'/',headers=headers),timeout=2) as r:
            html=r.read().decode();policy=r.headers['Content-Security-Policy']
        self.assertIn('id="market-chart"',html);self.assertIn('id="action"',html)
        self.assertIn('frame-src https://www.tradingview-widget.com;',policy)
        self.assertIn("script-src 'self';",policy);self.assertNotIn('unsafe-inline',policy)
    def test_status_never_exposes_secrets(self):
        code,s=self.request('/api/status');self.assertEqual(code,200);self.assertNotIn('api_key',s['config']);self.assertNotIn(self.app.webhook,json.dumps(s))
    def test_mutation_requires_csrf(self):self.assertEqual(self.request('/api/demo',{},csrf=False)[0],403)
    def test_cross_origin_rejected(self):self.assertEqual(self.request('/api/demo',{},origin='https://attacker.example')[0],403)
    def test_demo_is_isolated(self):
        self.request('/api/demo',{});status=self.app.status();self.assertEqual(status['summary']['closed'],0);self.assertIsNone(self.app.store.active());self.assertTrue(any(e['demo'] for e in status['events']))
    def test_webhook_ack_durable_and_fast(self):
        end=int(time.time()//300)*300;p=snapshot(end);start=time.monotonic();code,r=self.request('/webhook/'+self.app.webhook,p,auth=False)
        # The most recent boundary can be older than90s, so freeze only validation
        # time in this HTTP-only test while exercising the actual receiver/SQLite.
        if time.time()-end>90:
            from unittest.mock import patch
            with patch('app.validate_snapshot',lambda payload:validate_snapshot(payload,end)):
                start=time.monotonic();code,r=self.request('/webhook/'+self.app.webhook,p,auth=False)
        self.assertEqual(code,202);self.assertLess(time.monotonic()-start,1.5)
        with self.app.store.db() as c:self.assertIsNotNone(c.execute('SELECT id FROM events WHERE id=?',(event_key(p),)).fetchone())
    def test_wrong_webhook_or_order_route_rejected(self):
        self.assertEqual(self.request('/webhook/wrong',{},auth=False)[0],404);self.assertEqual(self.request('/api/orders',{})[0],404)
    def test_secret_field_cannot_enable_without_consent(self):
        code,r=self.request('/api/settings',{'ai_enabled':True,'api_key':'test','model':'test','data_consent':False});self.assertEqual(code,400)

if __name__=='__main__':unittest.main(verbosity=2)
