let state=null,csrf='',settingsLoaded=false,reconcileId=null;

const $=id=>document.getElementById(id);

const money=x=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(x);

const sydney=t=>new Date(t*1000).toLocaleString('en-AU',{timeZone:'Australia/Sydney',day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});

let chartInstrument=null;

function mountChart(instrument,force=false){if(!force&&chartInstrument===instrument)return;chartInstrument=instrument;const symbol='CME_MINI:'+instrument+'1!';const config={autosize:true,symbol,interval:'5',timezone:'Australia/Sydney',theme:'light',style:'1',locale:'en',allow_symbol_change:false,calendar:false,details:false,hide_side_toolbar:false,hide_top_toolbar:false,save_image:true,withdateranges:true,enable_publishing:false};$('market-chart').src='https://www.tradingview-widget.com/embed-widget/advanced-chart/?locale=en#'+encodeURIComponent(JSON.stringify(config));$('chart-title').textContent=instrument+' Nasdaq futures · TradingView';$('chart-credit').href='https://www.tradingview.com/chart/?symbol='+encodeURIComponent(symbol)+'&interval=5'}

function connectionSteps(s){const c=s.config;const age=s.last_snapshot?Date.now()/1000-s.last_snapshot:Infinity;return [s.preview?'Deploy the online receiver — this app is still local.':null,!s.worker_alive?'Restart the signal worker.':null,age>=420?'Connect a TradingView webhook alert — no recent market candles received.':null,!c.feed_confirmed?'Confirm real-time futures data on the alert’s TradingView chart.':null,!c.api_key_configured?'Add your OpenAI API key.':null,!c.model?'Choose an API model.':null,!c.data_consent?'Allow market-data review and API usage in Setup.':null,!c.ai_enabled?'Enable AI review.':null,!c.enabled?'Activate practice monitoring after the connections are ready.':null].filter(Boolean)}

function renderConnections(s){const steps=connectionSteps(s);$('live-title').textContent=steps.length?'SIGNALS NOT LIVE':'SIGNAL SERVICE CONNECTED · PRACTICE';$('live-detail').textContent=steps.length?steps[0]+' BUY/SELL signals remain unavailable until setup is complete.':'Waiting for a qualifying completed-candle setup. NO TRADE is a normal result.';$('live-connection').classList.toggle('connected',!steps.length);const ul=$('connection-checklist');ul.replaceChildren();for(const text of steps.length?steps:['Connections ready. Wait for a qualifying setup.']){const li=document.createElement('li');li.textContent=text;ul.append(li)}}

function toast(text){$('toast').textContent=text;$('toast').hidden=false;setTimeout(()=>$('toast').hidden=true,5500)}

async function post(path,body={}){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)});const j=await r.json();if(!r.ok)throw Error(j.error||'Request failed');return j}

function setStatus(id,text,ready){$(id).textContent=text;$(id).classList.toggle('ready',ready)}

function loadSettings(c){$('cfg-instrument').value=c.instrument;$('cfg-risk').value=c.max_risk_usd;$('cfg-loss').value=c.max_daily_loss_usd;$('cfg-count').value=c.max_signals_per_day;$('cfg-model').value=c.model;$('cfg-chat').value=c.telegram_chat_id;for(const [id,key] of [['cfg-feed','feed_confirmed'],['cfg-ai','ai_enabled'],['cfg-consent','data_consent'],['cfg-notify','telegram_enabled'],['cfg-notify-consent','notifications_consent'],['cfg-enabled','enabled']])$(id).checked=c[key];$('cfg-key').placeholder=c.api_key_configured?'Key saved · leave blank to keep':'Paste your API key';$('cfg-telegram').placeholder=c.telegram_token_configured?'Token saved · leave blank to keep':'Paste your bot token'}

function render(s){state=s;csrf=s.csrf;const c=s.config;mountChart(c.instrument);renderConnections(s);$('offline').hidden=true;$('mode').textContent=s.preview?'LOCAL DEMO · NOT ONLINE':c.enabled?'PRACTICE MONITORING':'PRACTICE · PAUSED';$('risk-limit').textContent=money(c.max_risk_usd);$('instrument').textContent='1 '+c.instrument;$('tv-chart').href='https://www.tradingview.com/chart/?symbol='+encodeURIComponent('CME_MINI:'+c.instrument+'1!')+'&interval=5';$('tv-chart').textContent='View '+c.instrument+' in TradingView ↗';

 const age=s.last_snapshot?Date.now()/1000-s.last_snapshot:Infinity;setStatus('feed-state',age<420?'Receiving snapshots':s.last_snapshot?'No recent snapshot':'Not connected',age<420);setStatus('ai-state',c.ai_enabled?'Configured · not profit-validated':'Not configured',c.ai_enabled);setStatus('phone-state',c.telegram_enabled?'Enabled':'Not configured',c.telegram_enabled);setStatus('service-state',c.enabled&&s.worker_alive?'Monitoring':s.worker_alive?'Paused':'Worker unavailable',c.enabled&&s.worker_alive);

 $('closed').textContent=s.summary.closed;$('pnl').textContent=money(s.summary.net_usd);$('win-rate').textContent=s.summary.win_rate===null?'—':(s.summary.win_rate*100).toFixed(1)+'%';$('reviews').textContent=s.reviews_today;

 $('profit-factor').textContent=s.summary.profit_factor===null?'—':s.summary.profit_factor.toFixed(2);$('expectancy').textContent=s.summary.expectancy_usd===null?'—':money(s.summary.expectancy_usd);$('drawdown').textContent=money(s.summary.closed_drawdown_usd);$('daily-budget').textContent=money(s.daily_remaining_usd);

 const evaluations=$('evaluations');evaluations.replaceChildren();

 for(const g of s.evaluations||[]){const tr=document.createElement('tr');const outcome=x=>`${x.closed} closed · ${money(x.net_usd)} · PF ${x.profit_factor===null?'—':x.profit_factor.toFixed(2)}`;for(const value of [g.model+' / '+g.rule_version,outcome(g.all_reviewed),outcome(g.approved),outcome(g.vetoed),`${g.pending} pending · ${g.unresolved} gaps · ${g.unavailable} unavailable reviews`]){const td=document.createElement('td');td.textContent=value;tr.append(td)}evaluations.append(tr)}

 const latest=s.events.find(x=>x.decision&&!x.demo);if(latest){const d=latest.decision;const expired=d.expires&&Date.now()/1000>d.expires;const old=d.time&&Date.now()/1000-d.time>90;const inactive=!c.enabled||!c.ai_enabled||!c.feed_confirmed||!s.worker_alive;const action=expired||old||inactive?'NO TRADE':d.action;$('action').textContent=action;$('action').className=action==='BUY'?'buy':action==='SELL'?'sell':'';$('reason').textContent=inactive?'Signal service is paused or incomplete. Open Connect signals to finish setup.':expired||old?'Previous assessment is old. Wait for a fresh signal before considering an entry.':d.reason;$('signal-mode').textContent=expired||old?'PAST ASSESSMENT':'PRACTICE';for(const [id,key] of [['entry','reference_entry'],['stop','stop'],['target','target']])$(id).textContent=!expired&&!old&&!inactive&&typeof d[key]==='number'?d[key].toFixed(2):'—';$('signal-time').textContent=sydney(latest.received);$('signal-rule').textContent=d.rule||'Experimental research · no orders';}else{$('action').textContent='NO TRADE';$('action').className='';$('reason').textContent='Waiting for TradingView market data. Demo examples in the journal are not live signals.';$('signal-mode').textContent='NOT CONNECTED';for(const id of ['entry','stop','target'])$(id).textContent='—';$('signal-time').textContent='No TradingView snapshot received';$('signal-rule').textContent='No live prices or trade levels available';}

 const body=$('journal');body.replaceChildren();if(!s.events.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=5;td.className='empty';td.textContent='Your first assessment will appear here.';tr.append(td);body.append(tr)}

 for(const e of s.events.slice(0,30)){const d=e.decision||{action:'QUEUED',reason:'Waiting for review'};const tr=document.createElement('tr');const cells=[sydney(e.received),d.action,e.ticker,d.reason,e.demo?'DEMO':'PRACTICE'];cells.forEach((value,i)=>{const td=document.createElement('td');if(i===1){const badge=document.createElement('span');badge.className='tag '+(d.action==='BUY'?'buy':d.action==='SELL'?'sell':'no');badge.textContent=value;td.append(badge)}else td.textContent=value;if(i===3)td.className='reason';tr.append(td)});body.append(tr)}

 const active=s.positions.find(x=>['open','pending','unresolved'].includes(x.state)&&!x.demo);$('position-section').hidden=!active;if(active){$('position-text').textContent=active.state==='unresolved'?active.reason:active.state==='pending'?'Waiting for the next candle to model an entry. Reference alert prices are not fill prices.':`Modeled ${active.side===1?'BUY':'SELL'} · Entry ${active.entry.toFixed(2)} · SL ${active.stop.toFixed(2)} · TP ${active.target.toFixed(2)}. This is not your actual account position.`;$('reconcile-form').hidden=active.state!=='unresolved';reconcileId=active.id}

 if(!settingsLoaded){loadSettings(c);settingsLoaded=true}

}

async function refresh(){try{const r=await fetch('/api/status',{cache:'no-store'});if(!r.ok)throw Error('Connection failed');render(await r.json())}catch(e){$('offline').hidden=false;$('action').textContent='NO TRADE';$('action').className='';$('signal-mode').textContent='DISCONNECTED';$('reason').textContent='Cannot reach the signal service. No current BUY or SELL is available.';for(const id of ['entry','stop','target'])$(id).textContent='—';$('live-title').textContent='SIGNAL SERVICE OFFLINE';$('live-detail').textContent='The chart may load independently. Restart the local service to reconnect signals.';}}

$('setup-button').onclick=()=>{if(state)loadSettings(state.config);$('setup').showModal()};$('close-setup').onclick=()=>$('setup').close();

$('demo-button').onclick=async()=>{try{await post('/api/demo');await refresh();toast('Three synthetic examples added. No AI call or notification was sent.')}catch(e){toast(e.message)}};

$('settings-form').onsubmit=async e=>{e.preventDefault();const b={instrument:$('cfg-instrument').value,max_risk_usd:Number($('cfg-risk').value),max_daily_loss_usd:Number($('cfg-loss').value),max_signals_per_day:Number($('cfg-count').value),model:$('cfg-model').value.trim(),api_key:$('cfg-key').value.trim(),telegram_token:$('cfg-telegram').value.trim(),telegram_chat_id:$('cfg-chat').value.trim(),feed_confirmed:$('cfg-feed').checked,ai_enabled:$('cfg-ai').checked,data_consent:$('cfg-consent').checked,telegram_enabled:$('cfg-notify').checked,notifications_consent:$('cfg-notify-consent').checked,enabled:$('cfg-enabled').checked};try{await post('/api/settings',b);$('cfg-key').value='';$('cfg-telegram').value='';$('save-message').textContent='Settings saved. Configuration does not establish a profitable strategy.';await refresh()}catch(e){$('save-message').textContent=e.message}};

$('connection-button').onclick=async()=>{try{const r=await post('/api/connection');$('webhook').value=location.origin+r.webhook_path;$('webhook').hidden=false;$('connection-warning').textContent=state.preview?'This is a local preview URL. TradingView cannot reach it. Deploy the hosted version first.':'Use this private HTTPS URL in your TradingView alert.'}catch(e){toast(e.message)}};

$('reconcile-form').onsubmit=async e=>{e.preventDefault();try{await post('/api/reconcile',{id:reconcileId,result:Number($('reconcile-result').value)});await refresh()}catch(e){toast(e.message)}};

setInterval(()=>{$('clock').textContent=new Date().toLocaleTimeString('en-AU',{timeZone:'Australia/Sydney',hour:'2-digit',minute:'2-digit'})},1000);setInterval(refresh,5000);refresh();



$('fix-connection').onclick=()=>$('setup-button').click();$('reload-chart').onclick=()=>mountChart(state?state.config.instrument:'NQ',true);mountChart('NQ');

