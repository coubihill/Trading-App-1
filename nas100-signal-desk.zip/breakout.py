"""Frozen exploratory MNQ candidate. Not connected to live signal selection."""
import math

VERSION='mnq-range-break-forward-1'

def candidate(p,core):
    if p['root']!='MNQ':return None,'Breakout experiment uses actual MNQ only'
    end=p['bar_end']/1000;dt=core.datetime.fromtimestamp(end,core.SYDNEY)
    if dt.weekday()>4 or not 660<=dt.hour*60+dt.minute<1020:return None,'Outside breakout experiment window'
    b=p['candles'];recent=b[-14:]
    if any(recent[i]['t']-recent[i-1]['t']!=300000 for i in range(1,len(recent))):return None,'Breakout setup has a data gap'
    last=b[-1];prior=b[-13:-1];hi=max(x['h'] for x in prior);lo=min(x['l'] for x in prior);a=p['atr']
    side=1 if last['c']>hi+.25 and last['c']-last['o']>=.5*a else -1 if last['c']<lo-.25 and last['o']-last['c']>=.5*a else 0
    if not side:return None,'No frozen breakout setup'
    flat=dt.replace(hour=17,minute=0,second=0,microsecond=0).timestamp()
    if end+300>=flat:return None,'No future entry before session exit'
    risk=math.ceil(a*4)/4;entry=core.round_tick(last['c']+side*.5)
    return {'action':'BUY' if side==1 else 'SELL','side':side,'rule':'Frozen 12-bar breakout','rule_version':VERSION,
            'ticker':p['ticker'],'root':'MNQ','signal_time':end,'date':core.local_date(end),'reference_entry':entry,
            'stop':entry-side*risk,'target':entry+side*2*risk,'risk_points':risk,'reward_risk':2.,
            'estimated_risk_usd':round((risk+.5)*2+1.22,2),'expires':min(end+7200,flat),
            'features':{'atr':a,'body_15m':last['c']-b[-3]['o'],'range_15m':max(x['h'] for x in b[-3:])-min(x['l'] for x in b[-3:]),
                        'ema9':p['ema9'],'ema20':p['ema20'],'ema20_lag3':p['ema20_lag3']}},'Frozen breakout research candidate'


def advance_position(position,p,core):
    """Shared execution assumptions for approved positions and counterfactuals."""
    r=dict(position)
    if r['ticker']!=p['ticker'] or r['state'] in ['unresolved','closed']:return r
    bars=[b for b in p['candles'] if b['t']/1000>=r['signal_time'] and (r['last_bar'] is None or b['t']/1000>r['last_bar'])]
    if not bars:return r
    expected=r['signal_time'] if r['state']=='pending' else r['last_bar']+300
    for b in bars:
        t=b['t']/1000
        if t!=expected:
            r.update(state='unresolved',reason='Gap in paper-position data; no outcome assumed');break
        if r['state']=='pending':
            entry=core.round_tick(b['o']+r['side']*.5)
            r.update(state='open',entry=entry,stop=core.round_tick(entry-r['side']*r['risk']),target=core.round_tick(entry+r['side']*2*r['risk']))
        side=r['side'];ex=None;reason=None
        if t>=r['expires']:ex=b['o']-side*.5;reason='Time exit'
        else:
            sh=b['l']<=r['stop'] if side==1 else b['h']>=r['stop']
            th=b['h']>=r['target']+.25 if side==1 else b['l']<=r['target']-.25
            if sh:ex=(min(r['stop'],b['o']) if side==1 else max(r['stop'],b['o']))-side*.5;reason='Stop; five-minute stop-first model'
            elif th:ex=r['target'];reason='Target'
        r['last_bar']=t;expected=t+300
        if ex is not None:
            r.update(state='closed',exit=ex,result=round((side*(ex-r['entry'])-2)*core.POINT_VALUE[r['root']],2),reason=reason);break
    return r
