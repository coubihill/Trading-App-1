"""Practice signals only. No broker integration or order endpoints."""
from __future__ import annotations
import hashlib,json,math,re,sqlite3,time,urllib.request
import learning
from contextlib import contextmanager
from datetime import datetime
from zoneinfo import ZoneInfo

SYDNEY=ZoneInfo('Australia/Sydney')
POINT_VALUE={'MNQ':2.0,'NQ':20.0}
RULE_VERSION='sydney-research-1'
ENGINE_VERSION='1.3.1'
DEFAULTS={'enabled':False,'ai_enabled':False,'model':'','api_key':'','data_consent':False,
          'feed_confirmed':False,'instrument':'MNQ','max_risk_usd':200.,'max_daily_loss_usd':200.,
          'max_signals_per_day':1,'max_ai_calls_per_day':12,'telegram_enabled':False,
          'telegram_token':'','telegram_chat_id':'','notifications_consent':False}

def finite(value):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):raise ValueError('Expected a finite number')
    return float(value)

def validate_snapshot(p,now=None):
    now=time.time() if now is None else now
    allowed={'version','ticker','root','timeframe','bar_end','atr','ema9','ema20','ema20_lag3','candles'}
    if not isinstance(p,dict) or set(p)!=allowed:raise ValueError('Unexpected or missing snapshot fields')
    if p['version']!=1 or p['timeframe']!='5':raise ValueError('Use bridge version1 on five-minute candles')
    if p['root'] not in POINT_VALUE:raise ValueError('Use an NQ or MNQ futures chart')
    if not isinstance(p['ticker'],str) or not re.fullmatch(r'[A-Z0-9_]+:(?:MNQ|NQ)[A-Z0-9!]{0,12}',p['ticker']):raise ValueError('Unsupported futures symbol')
    symbol=p['ticker'].split(':',1)[1]
    if not symbol.startswith(p['root']) or (p['root']=='NQ' and symbol.startswith('MNQ')):raise ValueError('Instrument and symbol disagree')
    end=finite(p['bar_end'])/1000
    if end%300!=0:raise ValueError('Snapshot must end on a five-minute boundary')
    if now-end>90:raise ValueError('Market data is stale; newest completed candle is over90seconds old')
    if end-now>5:raise ValueError('Market data is future dated')
    if not isinstance(p['candles'],list) or len(p['candles'])!=64:raise ValueError('Exactly64 completed candles are required')
    previous=None;clean=[]
    for b in p['candles']:
        if not isinstance(b,dict) or set(b)!={'t','o','h','l','c'}:raise ValueError('Invalid candle fields')
        b={k:finite(v) for k,v in b.items()}
        if b['t']%300000!=0 or b['t']/1000>=end:raise ValueError('Candle timestamps must precede snapshot end')
        if previous is not None and b['t']<=previous:raise ValueError('Candles must be strictly chronological')
        if not 0<b['l']<=min(b['o'],b['c'])<=max(b['o'],b['c'])<=b['h'] or b['h']>1_000_000:raise ValueError('Invalid OHLC prices')
        previous=b['t'];clean.append(b)
    if clean[-1]['t']/1000+300!=end:raise ValueError('Missing newest completed candle')
    q=dict(p,candles=clean,bar_end=int(end*1000))
    for k in ['atr','ema9','ema20','ema20_lag3']:
        q[k]=finite(q[k])
        if not 0<q[k]<1_000_000:raise ValueError('Invalid indicator value')
    if q['atr']>q['candles'][-1]['c']*.2:raise ValueError('ATR is inconsistent with market price')
    return q

def event_key(p):return hashlib.sha256(f"{p['ticker']}|5|{p['bar_end']}".encode()).hexdigest()
def local_date(ts):return datetime.fromtimestamp(ts,SYDNEY).strftime('%Y-%m-%d')
def round_tick(x):return math.floor(x/.25+.5)*.25

def performance(rows):
    """Closed journal outcomes; null PF means there are no realized losses."""
    rows=sorted((r for r in rows if r['state']=='closed' and not r.get('demo',0)),key=lambda r:(r.get('last_bar') or 0,r['id']))
    values=[float(r['result']) for r in rows if r['result'] is not None]
    gains=sum(max(x,0) for x in values);losses=-sum(min(x,0) for x in values)
    equity=peak=drawdown=0.
    for x in values:
        equity+=x;peak=max(peak,equity);drawdown=max(drawdown,peak-equity)
    return {'closed':len(values),'wins':sum(x>0 for x in values),'net_usd':round(sum(values),2),
            'win_rate':sum(x>0 for x in values)/len(values) if values else None,
            'profit_factor':gains/losses if losses else None,'gross_profit':round(gains,2),
            'gross_loss':round(losses,2),'expectancy_usd':round(sum(values)/len(values),2) if values else None,
            'closed_drawdown_usd':round(drawdown,2),'reconciled':sum(r.get('reason')=='User journal reconciliation' for r in rows)}

def remaining_daily_budget(pnl,limit):
    # Profits do not increase the original daily risk allowance.
    return max(0.,float(limit)+min(float(pnl),0.))

def advance_position(position,p):
    """Shared execution assumptions for approved positions and counterfactuals."""
    r=dict(position)
    if r['ticker']!=p['ticker'] or r['state'] in ['unresolved','closed']:return r
    bars=[b for b in p['candles'] if b['t']/1000>=r['signal_time'] and (r['last_bar'] is None or b['t']/1000>r['last_bar'])]
    if not bars:return r
    expected=r['signal_time'] if r['state']=='pending' else r['last_bar']+300
    for b in bars:
        t=b['t']/1000
        if t!=expected:
            r.update(state='unresolved',reason='Gap in paper-position data; no outcome assumed');break
        if r['state']=='pending':
            entry=round_tick(b['o']+r['side']*.5)
            r.update(state='open',entry=entry,stop=round_tick(entry-r['side']*r['risk']),target=round_tick(entry+r['side']*3*r['risk']))
        side=r['side'];ex=None;reason=None
        if t>=r['expires']:ex=b['o']-side*.5;reason='Time exit'
        else:
            sh=b['l']<=r['stop'] if side==1 else b['h']>=r['stop']
            th=b['h']>=r['target']+.25 if side==1 else b['l']<=r['target']-.25
            if sh:ex=(min(r['stop'],b['o']) if side==1 else max(r['stop'],b['o']))-side*.5;reason='Stop; five-minute stop-first model'
            elif th:ex=r['target'];reason='Target'
        r['last_bar']=t;expected=t+300
        if ex is not None:
            r.update(state='closed',exit=ex,result=round((side*(ex-r['entry'])-2)*POINT_VALUE[r['root']],2),reason=reason);break
    return r

def candidate(p):
    """Fixed experimental hypotheses; AI cannot invent a fourth rule."""
    end=p['bar_end']/1000;dt=datetime.fromtimestamp(end,SYDNEY);minute=dt.hour*60+dt.minute
    if dt.weekday()>=5:return None,'Outside Sydney trading weekdays'
    if minute<660 or minute>1020:return None,'Outside the11AM–5PM Sydney entry window'
    if minute not in [690,840,900]:return None,'Monitoring; no scheduled research setup on this candle'
    b=p['candles'];need=13 if minute==690 else 6
    if any(b[j]['t']-b[j-1]['t']!=300000 for j in range(len(b)-need+1,len(b))):return None,'Required setup candles contain a market-data gap'
    atr=p['atr'];last=b[-1];high=max(x['h'] for x in b[-3:]);low=min(x['l'] for x in b[-3:]);width=high-low
    body=last['c']-b[-3]['o']
    if width<=0:return None,'Opening range has no width'
    if any(abs(b[j]['o']-b[j-1]['c'])>4*atr for j in range(len(b)-3,len(b))):return None,'Recent price gap is too large for this model'
    side=1 if body>0 else -1 if body<0 else 0
    if minute==690:
        previous=b[-13:-1];prior_high=max(x['h'] for x in previous);prior_low=min(x['l'] for x in previous)
        compressed=b[-4:-1];ch=max(x['h'] for x in compressed);cl=min(x['l'] for x in compressed)
        if ch-cl>.6*(prior_high-prior_low):return None,'No compression setup'
        side=1 if last['c']>ch+.25 else -1 if last['c']<cl-.25 else 0
        name='11:30 compression breakout'
    elif minute==840:
        trend=1 if p['ema9']>p['ema20']>p['ema20_lag3'] else -1 if p['ema9']<p['ema20']<p['ema20_lag3'] else 0
        if not trend or trend*body<=0:return None,'Trend and recent price direction do not agree'
        side=trend;name='14:00 trend continuation'
    else:
        if not side or abs(body)<.6*width or (high-last['c'] if side==1 else last['c']-low)>.2*width:return None,'No strong momentum setup'
        name='15:00 strong momentum'
    if not side:return None,'Price has not broken the setup range'
    distance=max(atr,last['c']-low+.25 if side==1 else high-last['c']+.25)
    risk=math.ceil(distance/.25)*.25
    if minute==840 and risk<10:return None,'Stop distance is too small relative to modeled costs'
    entry=round_tick(last['c']+side*.5);stop=round_tick(entry-side*risk);target=round_tick(entry+side*3*risk)
    return {'action':'BUY' if side==1 else 'SELL','side':side,'rule':name,'rule_version':RULE_VERSION,
            'ticker':p['ticker'],'root':p['root'],'signal_time':end,'date':local_date(end),
            'reference_entry':entry,'stop':stop,'target':target,'risk_points':risk,'reward_risk':3.,
            'estimated_risk_usd':round((risk+2+.5)*POINT_VALUE[p['root']],2),
            'expires':end+5*3600,'features':{'atr':atr,'body_15m':body,'range_15m':width,
                'ema9':p['ema9'],'ema20':p['ema20'],'ema20_lag3':p['ema20_lag3']}},'Research setup detected'

class Store:
    def __init__(self,path):
        self.path=str(path)
        with self.db() as c:
            c.executescript('''PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1), data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY, received REAL, bar_end REAL, ticker TEXT, payload TEXT, status TEXT DEFAULT 'queued', decision TEXT, demo INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS positions(id TEXT PRIMARY KEY, event_id TEXT, ticker TEXT, root TEXT, side INTEGER, signal_time REAL, expires REAL, risk REAL, entry REAL, stop REAL, target REAL, state TEXT, last_bar REAL, exit REAL, result REAL, reason TEXT, demo INTEGER DEFAULT 0);
            CREATE TABLE IF NOT EXISTS reviews(id TEXT PRIMARY KEY, day TEXT, created REAL);
            CREATE TABLE IF NOT EXISTS ai_budget(id TEXT PRIMARY KEY, month TEXT NOT NULL, reserved_cents INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS feed_delivery(id INTEGER PRIMARY KEY CHECK(id=1), received REAL NOT NULL, accepted INTEGER NOT NULL, reason TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS notifications(event_id TEXT PRIMARY KEY,status TEXT,updated REAL);
            CREATE TABLE IF NOT EXISTS evaluations(id TEXT PRIMARY KEY, model TEXT NOT NULL, rule_version TEXT NOT NULL, verdict TEXT NOT NULL, outcome TEXT NOT NULL, state TEXT NOT NULL, ticker TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS evaluations_active ON evaluations(ticker,state);
            ''')
            c.execute('INSERT OR IGNORE INTO settings VALUES(1,?)',(json.dumps(DEFAULTS),))
            c.execute("UPDATE events SET status='done',decision=? WHERE status='processing'",(json.dumps({'action':'NO TRADE','reason':'Service restarted during review; signal not replayed'}),))
        learning.init(self)
    @contextmanager
    def db(self):
        c=sqlite3.connect(self.path,timeout=2);c.row_factory=sqlite3.Row
        try:
            with c:yield c
        finally:c.close()
    def config(self):
        with self.db() as c:return dict(DEFAULTS,**json.loads(c.execute('SELECT data FROM settings WHERE id=1').fetchone()[0]))
    def update_config(self,data):
        current=self.config();allowed=set(DEFAULTS)
        if not isinstance(data,dict) or set(data)-allowed:raise ValueError('Unknown settings')
        for key in ['enabled','ai_enabled','data_consent','feed_confirmed','telegram_enabled','notifications_consent']:
            if key in data and not isinstance(data[key],bool):raise ValueError('Invalid switch')
        for key in ['max_risk_usd','max_daily_loss_usd']:
            if key in data and not 1<=finite(data[key])<=1000:raise ValueError('Risk limits must be between$1 and$1,000')
        for key in ['max_signals_per_day','max_ai_calls_per_day']:
            if key in data and (not isinstance(data[key],int) or isinstance(data[key],bool) or not 1<=data[key]<=50):raise ValueError('Invalid daily limit')
        for key in ['model','api_key','telegram_token','telegram_chat_id']:
            if key in data and (not isinstance(data[key],str) or len(data[key])>600 or any(ord(x)<32 for x in data[key])):raise ValueError('Invalid text setting')
        if 'instrument' in data and data['instrument'] not in POINT_VALUE:raise ValueError('Choose MNQ or NQ')
        # Blank password fields keep an existing secret. An explicit disable switch stops use.
        for key in ['api_key','telegram_token']:
            if key in data and not data[key]:data.pop(key)
        current.update(data)
        if current['ai_enabled'] and (not current['api_key'] or not current['model'] or not current['data_consent']):raise ValueError('AI needs a model, API key and market-data sharing consent')
        if current['telegram_enabled'] and (not current['telegram_token'] or not re.fullmatch(r'-?[0-9]{1,20}',current['telegram_chat_id']) or not current['notifications_consent']):raise ValueError('Telegram needs a bot token, numeric chat ID and notification consent')
        with self.db() as c:c.execute('UPDATE settings SET data=? WHERE id=1',(json.dumps(current),))
        return current
    def enqueue(self,p,now=None):
        now=time.time() if now is None else now;key=event_key(p)
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT COUNT(*) FROM events WHERE status IN ('queued','processing')").fetchone()[0]>=100:raise ValueError('Signal queue is full')
            cur=c.execute('INSERT OR IGNORE INTO events(id,received,bar_end,ticker,payload) VALUES(?,?,?,?,?)',(key,now,p['bar_end']/1000,p['ticker'],json.dumps(p)))
            return key,cur.rowcount==1
    def claim(self):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE');r=c.execute("SELECT * FROM events WHERE status='queued' ORDER BY received,id LIMIT 1").fetchone()
            if r:c.execute("UPDATE events SET status='processing' WHERE id=?",(r['id'],))
            return dict(r) if r else None
    def finish(self,key,decision):
        with self.db() as c:c.execute("UPDATE events SET status='done',decision=? WHERE id=?",(json.dumps(decision),key))
    def active(self):
        with self.db() as c:
            r=c.execute("SELECT * FROM positions WHERE demo=0 AND state IN ('pending','open','unresolved') LIMIT 1").fetchone()
            return dict(r) if r else None
    def daily(self,date):
        with self.db() as c:
            positions=[dict(r) for r in c.execute('SELECT * FROM positions WHERE demo=0')]
        entered=[r for r in positions if local_date(r['signal_time'])==date]
        return len(entered),sum(r['result'] or 0 for r in positions if r['state']=='closed' and r['last_bar'] and local_date(r['last_bar'])==date)
    def statistics(self):
        with self.db() as c:rows=[dict(r) for r in c.execute('SELECT * FROM positions WHERE demo=0')]
        return performance(rows)
    def track_review(self,key,candidate,model,verdict):
        r=candidate
        outcome={'id':key,'ticker':r['ticker'],'root':r['root'],'side':r['side'],
                 'signal_time':r['signal_time'],'expires':r['expires'],'risk':r['risk_points'],
                 'state':'pending','last_bar':None,'entry':None,'stop':None,'target':None,
                 'exit':None,'result':None,'reason':None,'demo':0}
        with self.db() as c:c.execute('INSERT OR IGNORE INTO evaluations VALUES(?,?,?,?,?,?,?)',(key,model,RULE_VERSION,verdict,json.dumps(outcome),'pending',r['ticker']))
    def advance_evaluations(self,p):
        with self.db() as c:
            for row in c.execute("SELECT id,outcome FROM evaluations WHERE ticker=? AND state IN ('pending','open')",(p['ticker'],)).fetchall():
                before=json.loads(row['outcome']);after=advance_position(before,p)
                if after!=before:c.execute('UPDATE evaluations SET outcome=?,state=? WHERE id=?',(json.dumps(after),after['state'],row['id']))
    def evaluation_statistics(self):
        with self.db() as c:rows=[dict(r) for r in c.execute('SELECT * FROM evaluations')]
        groups={}
        for row in rows:
            key=(row['model'],row['rule_version'])
            groups.setdefault(key,[]).append(dict(json.loads(row['outcome']),verdict=row['verdict']))
        result=[]
        for (model,version),items in sorted(groups.items()):
            valid=[r for r in items if r['verdict'] in ['APPROVE','VETO']]
            result.append({'model':model,'rule_version':version,'reviewed':len(items),
                           'pending':sum(r['state'] in ['pending','open'] for r in items),
                           'unresolved':sum(r['state']=='unresolved' for r in items),
                           'unavailable':sum(r['verdict']=='UNAVAILABLE' for r in items),
                           'all_reviewed':performance(valid),
                           'approved':performance([r for r in valid if r['verdict']=='APPROVE']),
                           'vetoed':performance([r for r in valid if r['verdict']=='VETO'])})
        return result
    def reserve_review(self,key,day,maximum):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute('SELECT COUNT(*) FROM reviews WHERE day=?',(day,)).fetchone()[0]>=maximum:return False
            # Conservative reservation, never refunded on timeouts. This service only.
            month=time.strftime('%Y-%m',time.gmtime())
            used=c.execute('SELECT COALESCE(SUM(reserved_cents),0) FROM ai_budget WHERE month=?',(month,)).fetchone()[0]
            if used+10>500:return False
            c.execute('INSERT INTO ai_budget VALUES(?,?,10)',(key,month))
            c.execute('INSERT INTO reviews VALUES(?,?,?)',(key,day,time.time()));return True
    def ai_budget_status(self):
        month=time.strftime('%Y-%m',time.gmtime())
        with self.db() as c:used=c.execute('SELECT COALESCE(SUM(reserved_cents),0) FROM ai_budget WHERE month=?',(month,)).fetchone()[0]
        return {'month_utc':month,'limit_usd':5,'reserved_usd':used/100,'reservation_per_call_usd':.10,'detail':'Conservative reservations, not actual billing. Covers this app only; no refund on failed calls.'}
    def record_delivery(self,accepted,reason):
        # Only authenticated webhook attempts; no token, payload or private URL stored.
        with self.db() as c:c.execute('INSERT OR REPLACE INTO feed_delivery VALUES(1,?,?,?)',(time.time(),int(accepted),reason))
    def feed_delivery_status(self):
        with self.db() as c:r=c.execute('SELECT received,accepted,reason FROM feed_delivery WHERE id=1').fetchone()
        return dict(r) if r else None
    def open_paper(self,key,candidate,decision):
        r=candidate
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT COUNT(*) FROM positions WHERE demo=0 AND state IN ('pending','open','unresolved')").fetchone()[0]:return False
            c.execute('INSERT INTO positions(id,event_id,ticker,root,side,signal_time,expires,risk,state) VALUES(?,?,?,?,?,?,?,?,?)',(key,key,r['ticker'],r['root'],r['side'],r['signal_time'],r['expires'],r['risk_points'],'pending'))
            c.execute("UPDATE events SET status='done',decision=? WHERE id=?",(json.dumps(decision),key))
            return True
    def advance(self,p):
        """Model next-bar entry, stop-first exits, and refuse gaps in monitoring."""
        r=self.active()
        if not r or r['ticker']!=p['ticker'] or r['state']=='unresolved':return
        r=advance_position(r,p)
        with self.db() as c:
            c.execute('UPDATE positions SET state=?,entry=?,stop=?,target=?,last_bar=?,exit=?,result=?,reason=? WHERE id=?',tuple(r.get(k) for k in ['state','entry','stop','target','last_bar','exit','result','reason','id']))
    def close_unresolved(self,key,result):
        result=finite(result)
        if not -100000<=result<=100000:raise ValueError('Invalid journal result')
        with self.db() as c:
            c.execute("UPDATE positions SET state='closed',result=?,last_bar=?,reason='User journal reconciliation' WHERE id=? AND state='unresolved'",(result,time.time(),key))

def review_ai(c,p,settings,transport=None):
    schema={'type':'object','properties':{'verdict':{'type':'string','enum':['APPROVE','VETO']},'reason':{'type':'string'}},'required':['verdict','reason'],'additionalProperties':False}
    if transport is None and settings['model']!='gpt-5.6-terra':raise ValueError('Model has no approved cost profile')
    request={'model':settings['model'],'store':False,'max_output_tokens':1200,
        'instructions':('Review an experimental paper-trading candidate. You may only APPROVE or VETO the supplied direction. You cannot change prices, risk, position size or rules. Use only the supplied numeric data. No current news, order flow or account state is supplied. Do not invent it or claim certainty, profitable performance or a win probability. VETO if evidence is insufficient or inconsistent. Explain briefly in plain English. The user executes no orders through this service.'),
        'input':json.dumps({'candidate':c,'completed_market_candles':p['candles'][-16:],'mode':'practice only'}),
        'text':{'format':{'type':'json_schema','name':'paper_trade_review','strict':True,'schema':schema}}}
    if settings['model']=='gpt-5.6-terra':request['reasoning']={'effort':'none'}
    encoded=json.dumps(request).encode()
    if len(encoded)>12000:raise ValueError('AI request exceeds cost-profile input limit')
    if transport is None:
        req=urllib.request.Request('https://api.openai.com/v1/responses',data=encoded,headers={'Authorization':'Bearer '+settings['api_key'],'Content-Type':'application/json'},method='POST')
        with urllib.request.urlopen(req,timeout=15) as response:raw=json.loads(response.read(200000))
    else:raw=transport(request)
    if raw.get('status')!='completed':raise ValueError('AI response was incomplete')
    texts=[]
    for item in raw.get('output',[]):
        if item.get('type')=='message':
            for part in item.get('content',[]):
                if part.get('type')=='refusal':raise ValueError('AI declined the review')
                if part.get('type')=='output_text':texts.append(part.get('text',''))
    obj=json.loads(''.join(texts))
    if not isinstance(obj,dict) or set(obj)!={'verdict','reason'} or obj['verdict'] not in ['APPROVE','VETO'] or not isinstance(obj['reason'],str) or not 1<=len(obj['reason'])<=400:raise ValueError('AI response did not match the required format')
    return obj

def process(store,event,reviewer=review_ai,clock=time.time):
    p=json.loads(event['payload']);key=event['id'];now=clock();cfg=store.config()
    decision={'action':'NO TRADE','reason':'','mode':'PRACTICE','time':now,'ticker':p['ticker'],'rule_version':RULE_VERSION,'engine_version':ENGINE_VERSION}
    def no(reason):decision['reason']=reason;return decision
    try:p=validate_snapshot(p,now)
    except ValueError as e:return no(str(e))
    with store.db() as con:
        newer=con.execute("SELECT 1 FROM events WHERE ticker=? AND bar_end>? AND status='done' AND demo=0 LIMIT 1",(p['ticker'],p['bar_end']/1000)).fetchone()
    if newer:return no('Out-of-order snapshot; a newer candle was already processed')
    store.advance(p)
    store.advance_evaluations(p)
    if not event.get('demo',0):
        learning.advance(store,p,advance_position,POINT_VALUE)
        learning.train_if_ready(store)
        if p['root']==cfg['instrument']:
            observed,_=candidate(p)
            if observed:learning.observe(store,key,observed)
    if not cfg['enabled']:return no('Service paused; setup is not activated')
    if p['root']!=cfg['instrument']:return no('Chart does not match the selected practice instrument')
    if not cfg['feed_confirmed']:return no('Confirm that your chart has real-time futures data')
    active=store.active()
    if active:return no('A modeled position is already active' if active['state']!='unresolved' else 'Paper-position data is incomplete; reconcile its journal result first')
    c,reason=candidate(p)
    if not c:return no(reason)
    decision['candidate']=c
    count,pnl=store.daily(c['date'])
    if count>=cfg['max_signals_per_day']:return no('Daily practice-signal limit reached')
    if pnl<=-cfg['max_daily_loss_usd']:return no('Modeled daily loss limit reached')
    if c['estimated_risk_usd']>cfg['max_risk_usd']:return no('Planned risk exceeds your practice limit')
    if c['estimated_risk_usd']>remaining_daily_budget(pnl,cfg['max_daily_loss_usd']):return no('Planned risk exceeds the remaining modeled daily loss budget')
    if not cfg['ai_enabled']:return no('AI review is not connected; no approval assumed')
    if not cfg['data_consent'] or not cfg['api_key'] or not cfg['model']:return no('AI review setup or market-data sharing consent is incomplete')
    if not store.reserve_review(key,c['date'],cfg['max_ai_calls_per_day']):return no('AI review budget or daily limit reached; no approval assumed')
    decision['model']=cfg['model'];started=time.monotonic()
    try:
        review=reviewer(c,p,cfg)
        if not isinstance(review,dict) or review.get('verdict') not in ['APPROVE','VETO'] or not isinstance(review.get('reason'),str) or not 1<=len(review['reason'])<=400:raise ValueError('Invalid AI review')
    except Exception:
        store.track_review(key,c,cfg['model'],'UNAVAILABLE')
        decision['review_seconds']=round(time.monotonic()-started,3)
        return no('AI review unavailable or invalid; no approval assumed')
    decision['review_seconds']=round(time.monotonic()-started,3)
    store.track_review(key,c,cfg['model'],review['verdict'])
    decision['ai']=review
    if clock()-p['bar_end']/1000>90:return no('Signal expired while awaiting AI review')
    # Settings may change while a remote request is in flight.
    latest=store.config()
    if latest['model']!=cfg['model'] or latest['api_key']!=cfg['api_key']:return no('AI configuration changed during review; signal cancelled')
    if not latest['enabled'] or not latest['ai_enabled'] or not latest['data_consent']:return no('Service settings changed during review; signal cancelled')
    if not latest['feed_confirmed'] or latest['instrument']!=p['root'] or c['estimated_risk_usd']>latest['max_risk_usd']:return no('Feed, instrument or risk limits changed during review; signal cancelled')
    latest_count,latest_pnl=store.daily(c['date'])
    if latest_count>=latest['max_signals_per_day'] or latest_pnl<=-latest['max_daily_loss_usd']:return no('Daily practice limit changed during review; signal cancelled')
    if c['estimated_risk_usd']>remaining_daily_budget(latest_pnl,latest['max_daily_loss_usd']):return no('Remaining daily risk budget changed during review; signal cancelled')
    if review['verdict']!='APPROVE':return no('AI veto: '+review['reason'])
    decision.update(action=c['action'],reason=review['reason'],reference_entry=c['reference_entry'],stop=c['stop'],target=c['target'],estimated_risk_usd=c['estimated_risk_usd'],expires=c['expires'],rule=c['rule'])
    if not store.open_paper(key,c,decision):
        decision['action']='NO TRADE'
        return no('Another modeled position is already active')
    return decision

def notify_telegram(store,key,decision,settings,transport=None):
    if decision['action'] not in ['BUY','SELL'] or not settings['telegram_enabled'] or not settings['notifications_consent']:return
    with store.db() as c:
        cursor=c.execute('INSERT OR IGNORE INTO notifications VALUES(?,?,?)',(key,'sending',time.time()))
        if not cursor.rowcount:return
    text=(f"PRACTICE {decision['action']} · {decision['ticker']}\nReference entry {decision['reference_entry']:.2f}\nSL {decision['stop']:.2f} · TP {decision['target']:.2f}\nEstimated risk ${decision['estimated_risk_usd']:.2f} for1contract\n{decision['rule']}\n{decision['reason']}\nResearch signal, not an executed trade. Check current price before acting.")
    status='sent'
    try:
        if transport:transport(text)
        else:
            req=urllib.request.Request('https://api.telegram.org/bot'+settings['telegram_token']+'/sendMessage',data=json.dumps({'chat_id':settings['telegram_chat_id'],'text':text}).encode(),headers={'Content-Type':'application/json'},method='POST')
            with urllib.request.urlopen(req,timeout=8) as response:
                if not json.loads(response.read(20000)).get('ok'):raise ValueError('Notification failed')
    except Exception:status='failed; inspect dashboard, not automatically retried'
    with store.db() as c:c.execute('UPDATE notifications SET status=?,updated=? WHERE event_id=?',(status,time.time(),key))
